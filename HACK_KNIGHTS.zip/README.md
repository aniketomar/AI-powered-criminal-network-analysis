# Sentinel Graph — Functional Investigation Intelligence MVP

Sentinel Graph is a investigation intelligence prototype backed by a **FastAPI + SQLite + NetworkX** service and a polished React frontend. It demonstrates unified synthetic case views, graph analysis, cross-case discovery, timeline intelligence, explainable local NLP, evidence validation, audit history, and import handling.

> **Safety and scope:** Every person, case, phone number, vehicle, location, organization, account, document, and relationship is fictional synthetic demo data. Indicators are analytical only, do not determine guilt or criminality, and require investigator validation. This prototype is not connected to CCTNS, ICJS, Digital Police, or any government system.

## Project structure

```text
backend/
  app/
    main.py                  FastAPI REST endpoints
    ai/extractor.py          deterministic NLP with no API key required
    database/db.py           SQLite schema, connection, and helpers
    database/seed.py         connected synthetic seed dataset
    graph/service.py         NetworkX graph, paths, stats, cross-case discovery
  tests/test_backend.py      backend tests
client/
  src/App.tsx                existing branded UI and navigation
  src/lib/api.ts             typed API client with graceful fallback
  src/lib/demoData.ts        local demo fallback data
```

## Windows setup

### Backend

From the project root in **PowerShell**:

```powershell
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r backend\requirements.txt
$env:PYTHONPATH = "backend"
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

From **Command Prompt**:

```bat
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r backend\requirements.txt
set PYTHONPATH=backend
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

SQLite initializes automatically at `data/sentinel_graph.db` and seeds the connected synthetic dataset on first startup.

### Frontend

Open a second terminal from the project root:

```powershell
pnpm install
$env:VITE_API_BASE_URL = "http://127.0.0.1:8000"
pnpm run dev
```

With npm instead:

```bat
npm install
set VITE_API_BASE_URL=http://127.0.0.1:8000
npm run dev
```

If the backend is unavailable, the frontend remains usable with its bundled synthetic fallback data and displays the offline/demo state.

## API surface

| Endpoint | Purpose |
|---|---|
| `GET /api/health` | Backend and database readiness |
| `GET /api/cases` | Synthetic case portfolio |
| `GET /api/cases/{case_id}` | Case detail, evidence, and network payload |
| `GET /api/entities` | Entity registry across people, vehicles, locations, organizations, phones, accounts, and documents |
| `GET /api/relationships` | Relationship records with evidence and validation state |
| `GET /api/network/{case_id}` | NetworkX graph nodes, edges, centrality, and graph statistics |
| `GET /api/timeline/{case_id}` | Timeline events with optional event-type filtering |
| `GET /api/cross-case` | Shared synthetic entities and explanations |
| `GET /api/search?q=UP16` | Search across entities, cases, and evidence |
| `GET /api/path?source=person-01&target=account-01` | Shortest relationship path with evidence reasons |
| `POST /api/analyze-text` | Rule-based entity and relationship extraction |
| `POST /api/validate` | Confirm, reject, defer, or annotate evidence/relationships and write audit history |
| `POST /api/import` | TXT, CSV, JSON, and PDF validation, extraction, and demo evidence ingestion |
| `GET /api/dashboard/stats` | Database-backed dashboard metrics |

Interactive API documentation is available at `http://127.0.0.1:8000/docs` while the backend is running.

## Tests and verification

```powershell
$env:PYTHONPATH = "backend"
python -m pytest -q backend/tests
pnpm exec tsc --noEmit
pnpm run build
```

The test suite covers database initialization, connected seed counts, entity and relationship extraction, pending-review defaults, shortest paths, cross-case discovery, search, validation, audit writes, and API endpoints.

## Demo flow

1. Click **Launch demo investigation** on the landing page.
2. Start in **Overview** and open `CASE-2026-001`.
3. Open **Network graph**, select `Arjun Sharma`, and inspect related synthetic nodes.
4. Open **Timeline** to sequence communication, vehicle, location, transaction, and evidence events.
5. Open **Cross-case discovery** to see shared vehicle, phone, location, and organization links.
6. Open **Evidence review** and confirm, reject, or defer an evidence item.
7. Open **Text analysis** and run the local deterministic extractor.

The dashboard keeps its existing visual design and transparently falls back to local data when no backend URL is configured.

## Hosted deployment

The project is upgraded to WebDev's backend-capable runtime. The root `Dockerfile` installs Python and the FastAPI requirements, builds the existing Node/React app, and starts the Node server. In production, Node starts FastAPI as a colocated child process and proxies same-origin `/api/*` requests to it. The browser therefore does not call `localhost`, `127.0.0.1`, or a development port.

`VITE_API_BASE_URL` is optional. Leave it empty for the hosted same-origin proxy; set it only when intentionally deploying FastAPI as a separate service. `CORS_ORIGINS` configures explicit local origins, while the FastAPI service allows the project's `*.manus.space` origin pattern. `DISABLE_FASTAPI_PROXY=1` is available only for a Node-only runtime and should not be used for the hosted full-stack deployment.

The finite production-style smoke test is `./verify_hosted_runtime.sh`. It starts the built Node server and colocated FastAPI process, checks same-origin health, statistics, cases, graph, path finding, search, text analysis, and import requests, then terminates the full process group.
