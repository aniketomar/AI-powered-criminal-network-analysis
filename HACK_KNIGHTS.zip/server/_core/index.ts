import "dotenv/config";
import express from "express";
import { createServer } from "http";
import http from "node:http";
import net from "net";
import path from "node:path";
import { spawn, type ChildProcess } from "node:child_process";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

let fastApiProcess: ChildProcess | undefined;

function stopFastApi() {
  if (fastApiProcess && !fastApiProcess.killed) fastApiProcess.kill("SIGTERM");
}

function startFastApi() {
  if (process.env.DISABLE_FASTAPI_PROXY === "1") return;
  const backendRoot = path.resolve(process.cwd(), "backend");
  fastApiProcess = spawn("python3", ["-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", "8000"], {
    cwd: backendRoot,
    env: { ...process.env, PYTHONPATH: backendRoot },
    stdio: ["ignore", "inherit", "inherit"],
  });
  fastApiProcess.on("error", (error) => console.error("[FastAPI] Failed to start:", error));
  fastApiProcess.on("exit", (code, signal) => console.warn(`[FastAPI] exited code=${code ?? "-"} signal=${signal ?? "-"}`));
  process.once("SIGTERM", () => { stopFastApi(); process.exit(0); });
  process.once("SIGINT", () => { stopFastApi(); process.exit(0); });
}

async function waitForFastApi(timeoutMs = 12_000) {
  if (!fastApiProcess) return;
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const response = await fetch("http://127.0.0.1:8000/api/health");
      if (response.ok) {
        console.log("[FastAPI] health check passed");
        return;
      }
    } catch {
      // FastAPI is still booting.
    }
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
  console.warn("[FastAPI] health check timed out; API proxy will keep serving retries");
}

function proxyFastApi(req: express.Request, res: express.Response, next: express.NextFunction) {
  if (req.path === "/trpc" || req.path.startsWith("/trpc/") || req.path.startsWith("/oauth") || req.path.startsWith("/storage")) return next();
  const upstream = http.request({
    hostname: "127.0.0.1",
    port: 8000,
    path: req.originalUrl,
    method: req.method,
    headers: { ...req.headers, host: "127.0.0.1:8000" },
  }, (upstreamResponse) => {
    res.status(upstreamResponse.statusCode || 502);
    Object.entries(upstreamResponse.headers).forEach(([key, value]) => {
      if (value !== undefined) res.setHeader(key, value as string | string[]);
    });
    upstreamResponse.pipe(res);
  });
  upstream.on("error", () => {
    if (!res.headersSent) res.status(503).json({ status: "offline", error: "FastAPI backend unavailable" });
    else res.end();
  });
  req.pipe(upstream);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  startFastApi();
  await waitForFastApi();
  // Keep the investigation API same-origin in production. The Docker runtime
  // starts FastAPI beside this Node process; the browser never targets :8000.
  app.use("/api", proxyFastApi);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  registerStorageProxy(app);
  registerOAuthRoutes(app);
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
