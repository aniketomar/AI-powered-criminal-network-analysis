import { describe, expect, it } from "vitest";

describe("Gemini project secret", () => {
  it("authenticates with Gemini without consuming generation credits", async () => {
    const apiKey = process.env.GEMINI_API_KEY;
    expect(apiKey, "GEMINI_API_KEY must be configured as a project secret").toBeTruthy();

    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(apiKey!)}`);
    expect(response.ok, `Gemini models endpoint returned ${response.status}`).toBe(true);

    const payload = (await response.json()) as { models?: unknown[] };
    expect(Array.isArray(payload.models)).toBe(true);
  }, 15_000);
});
