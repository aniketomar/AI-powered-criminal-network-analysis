#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
setsid env PORT=3100 NODE_ENV=production node dist/index.js >/tmp/sentinel-hosted-runtime.log 2>&1 &
server_pid=$!
cleanup() {
  child_pids=$(pgrep -P "$server_pid" 2>/dev/null || true)
  kill -- -"$server_pid" 2>/dev/null || true
  kill "$server_pid" 2>/dev/null || true
  for child_pid in $child_pids; do kill "$child_pid" 2>/dev/null || true; done
  for runtime_pid in $(pgrep -f '^node dist/index\.js$' 2>/dev/null || true) $(pgrep -f '^python3 -m uvicorn app\.main:app --host 127\.0\.0\.1 --port 8000$' 2>/dev/null || true); do
    kill "$runtime_pid" 2>/dev/null || true
  done
  wait "$server_pid" 2>/dev/null || true
}
trap cleanup EXIT
for attempt in $(seq 1 40); do
  if curl -fsS --max-time 2 http://127.0.0.1:3100/api/health >/tmp/sentinel-health.json; then break; fi
  sleep 0.25
done
curl -fsS http://127.0.0.1:3100/api/health | tee /tmp/sentinel-health.json
curl -fsS http://127.0.0.1:3100/api/dashboard/stats >/tmp/sentinel-stats.json
curl -fsS http://127.0.0.1:3100/api/cases >/tmp/sentinel-cases.json
curl -fsS http://127.0.0.1:3100/api/network/CASE-2026-001 >/tmp/sentinel-network.json
curl -fsS 'http://127.0.0.1:3100/api/path?source=person-01&target=account-01&case_id=CASE-2026-001' >/tmp/sentinel-path.json
curl -fsS 'http://127.0.0.1:3100/api/search?q=UP16' >/tmp/sentinel-search.json
curl -fsS -X POST http://127.0.0.1:3100/api/analyze-text -H 'Content-Type: application/json' -d '{"text":"Arjun Sharma contacted Ravi Verma using phone 9000000001."}' >/tmp/sentinel-analysis.json
runtime_id="HOSTED-RUNTIME-$(date +%s%N)"
printf 'id,description,case_id\n%s,Same-origin proxy import,CASE-2026-001\n' "$runtime_id" | curl -fsS -X POST http://127.0.0.1:3100/api/import -F 'file=@-;filename=hosted-runtime.csv;type=text/csv' >/tmp/sentinel-import.json
python3 - <<'PY'
import json
from pathlib import Path
health=json.loads(Path('/tmp/sentinel-health.json').read_text())
stats=json.loads(Path('/tmp/sentinel-stats.json').read_text())
cases=json.loads(Path('/tmp/sentinel-cases.json').read_text())
network=json.loads(Path('/tmp/sentinel-network.json').read_text())
path=json.loads(Path('/tmp/sentinel-path.json').read_text())
search=json.loads(Path('/tmp/sentinel-search.json').read_text())
analysis=json.loads(Path('/tmp/sentinel-analysis.json').read_text())
imported=json.loads(Path('/tmp/sentinel-import.json').read_text())
assert health['status']=='ok'
assert len(cases)>=4
assert stats['relationships']>0
assert network['nodes'] and network['edges']
assert path['found']
assert search['results']
assert analysis['entities']
assert imported['imported_count']==1
print(json.dumps({'health':health,'cases':len(cases),'nodes':len(network['nodes']),'edges':len(network['edges']),'path_found':path['found'],'search_results':len(search['results']),'analysis_entities':len(analysis['entities']),'imported':imported['imported_count']}, indent=2))
PY
