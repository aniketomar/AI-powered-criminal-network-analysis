import io
import json
import os
import time
from pathlib import Path
from pypdf import PdfWriter

os.environ["SENTINEL_DB_PATH"] = str(Path("data") / "sentinel_graph.db")
from fastapi.testclient import TestClient
from app.main import app
from app.database.db import init_db, rows

init_db()
client = TestClient(app)
checks = {}
checks["health"] = client.get("/api/health").json()
checks["cases"] = len(client.get("/api/cases").json())
checks["stats"] = client.get("/api/dashboard/stats").json()
checks["network"] = {k: len(client.get("/api/network/CASE-2026-001").json()[k]) for k in ("nodes", "edges")}
checks["cross_case"] = len(client.get("/api/cross-case").json())
checks["cross_case_evidence"] = any(item.get("evidence") is not None for item in client.get("/api/cross-case").json())
checks["entity_detail"] = client.get("/api/entities/person-01").json()
checks["timeline"] = len(client.get("/api/timeline/CASE-2026-001", params={"event_type": "Communication"}).json())
path_result = client.get("/api/path", params={"source": "person-01", "target": "account-01", "case_id": "CASE-2026-001"}).json()
checks["path"] = {"found": path_result["found"], "steps": len(path_result["edges"])}
checks["search"] = len(client.get("/api/search", params={"q": "UP16"}).json()["results"])
analysis = client.post("/api/analyze-text", json={"text": "Arjun Sharma contacted Ravi Verma using phone 9000000001. Vehicle UP16AB1234 was seen at Sector X Transit Yard. Transfer ₹85,000 to ACC-1001."}).json()
checks["analysis"] = {"entities": len(analysis["entities"]), "relationships": len(analysis["relationships"]), "pending": all(x["validation_status"] == "Pending Review" for x in analysis["relationships"])}
validation = client.post("/api/validate", json={"target_id": "EV-102", "target_type": "evidence", "action": "Confirm", "investigator": "Finite Verification", "note": "Bounded verification."})
checks["validation"] = validation.json()
import_id = f"FINITE-VERIFY-{int(time.time())}"
file = io.BytesIO(f"id,description,case_id\n{import_id},Bounded CSV import,CASE-2026-001\n".encode())
imported = client.post("/api/import", files={"file": ("finite.csv", file, "text/csv")})
checks["csv_import"] = imported.json()
json_id = f"FINITE-JSON-{int(time.time())}"
json_import = client.post("/api/import", files={"file": ("finite.json", io.BytesIO(json.dumps({"id": json_id, "description": "Bounded JSON import", "case_id": "CASE-2026-001"}).encode()), "application/json")})
checks["json_import"] = json_import.json()
txt_import = client.post("/api/import", files={"file": ("finite.txt", io.BytesIO(b"Arjun Sharma contacted Ravi Verma using phone 9000000001."), "text/plain")})
checks["txt_import"] = txt_import.json()
pdf = PdfWriter(); pdf.add_blank_page(width=300, height=300); pdf_buffer = io.BytesIO(); pdf.write(pdf_buffer); pdf_buffer.seek(0)
pdf_import = client.post("/api/import", files={"file": ("finite.pdf", pdf_buffer, "application/pdf")})
checks["pdf_import"] = pdf_import.json()
checks["refresh_evidence"] = len(client.get("/api/evidence").json())
checks["audit_rows"] = len(rows("SELECT * FROM audit_history WHERE target_id = ?", ("EV-102",)))
print(json.dumps(checks, indent=2, ensure_ascii=False))
assert checks["health"]["status"] == "ok"
assert checks["cases"] == 4
assert checks["stats"]["relationships"] >= 60
assert checks["network"]["nodes"] > 0 and checks["network"]["edges"] > 0
assert checks["cross_case"] > 0 and checks["cross_case_evidence"] and checks["search"] > 0
assert checks["entity_detail"]["relationships"] and checks["timeline"] > 0
assert checks["path"]["found"] and checks["path"]["steps"] > 0
assert checks["analysis"]["entities"] >= 6 and checks["analysis"]["pending"]
assert checks["validation"]["ok"] and checks["audit_rows"] > 0
assert checks["csv_import"]["imported_count"] == 1
assert checks["json_import"]["imported_count"] == 1
assert checks["txt_import"]["imported_evidence_id"].startswith("IMP-TEXT-")
assert checks["pdf_import"]["imported_evidence_id"].startswith("IMP-TEXT-")
assert checks["refresh_evidence"] >= checks["stats"]["evidence"]
