from __future__ import annotations

import json
import sqlite3
from datetime import date, timedelta


def seed(conn: sqlite3.Connection) -> None:
    cases = [
        ("CASE-2026-001", "North Corridor Logistics Review", "Organized logistics", "Active", "2026-03-04", "2026-03-18", "A. Menon", "Synthetic review of transport and financial activity across the North Corridor."),
        ("CASE-2026-002", "Harbor Signal Pattern", "Communications", "Under Review", "2026-03-09", "2026-03-17", "R. Iyer", "Synthetic communication metadata and recurring location visits."),
        ("CASE-2026-003", "Civic Procurement Anomaly", "Financial review", "Pending Validation", "2026-03-12", "2026-03-16", "S. Rao", "Synthetic transaction cluster with shared organizations and vehicle sightings."),
        ("CASE-2026-004", "East Ring Movement Study", "Vehicle intelligence", "Closed", "2026-02-18", "2026-03-11", "N. Khanna", "Closed synthetic comparison set for network analysis."),
    ]
    conn.executemany("INSERT INTO cases VALUES (?,?,?,?,?,?,?,?)", cases)

    case_ids = [c[0] for c in cases]
    people_names = ["Arjun Sharma", "Ravi Verma", "Meera Nair", "Kabir Sethi", "Ishita Rao", "Dev Malhotra", "Nisha Kapoor", "Aman Joshi", "Tara Menon", "Vikram Das", "Sonia Batra", "Neel Anand", "Pooja Sen", "Karan Gill", "Rhea Iyer", "Manav Shah", "Anika Bose", "Yash Mehta", "Diya Khanna", "Rohan Pillai"]
    people = []
    for i, name in enumerate(people_names, 1):
        memberships = [case_ids[i % 4]]
        if i in (1, 2, 3, 4, 5, 6, 7): memberships.append(case_ids[(i + 1) % 4])
        people.append((f"person-{i:02d}", name, f"phone-{(i % 10) + 1:02d}", json.dumps(sorted(set(memberships)))))
    conn.executemany("INSERT INTO people VALUES (?,?,?,?)", people)

    vehicles = []
    for i in range(1, 11):
        memberships = [case_ids[i % 4]]
        if i in (1, 2, 3, 7): memberships.append(case_ids[(i + 2) % 4])
        registration = "UP16 AB 1234" if i == 1 else f"DL{i:02d} XY {1000+i:04d}"
        vehicles.append((f"vehicle-{i:02d}", registration, json.dumps(sorted(set(memberships)))))
    conn.executemany("INSERT INTO vehicles VALUES (?,?,?)", vehicles)

    locations = [(f"location-{i:02d}", "Sector X Transit Yard" if i == 1 else f"Synthetic Location {i:02d}", json.dumps([case_ids[i % 4]] + ([case_ids[(i+1)%4]] if i in (1, 2, 5) else []))) for i in range(1, 16)]
    conn.executemany("INSERT INTO locations VALUES (?,?,?)", locations)
    organizations = [(f"org-{i:02d}", "Asterion Freight Co." if i == 1 else f"Synthetic Organization {i:02d}", json.dumps([case_ids[i % 4]] + ([case_ids[(i+2)%4]] if i in (1, 2, 4) else []))) for i in range(1, 11)]
    conn.executemany("INSERT INTO organizations VALUES (?,?,?)", organizations)
    phones = [(f"phone-{i:02d}", "+91 90000 00001" if i == 1 else f"+91 90000 00{i:04d}", json.dumps([case_ids[i % 4]] + ([case_ids[(i+1)%4]] if i in (1, 2, 4) else []))) for i in range(1, 11)]
    conn.executemany("INSERT INTO phones VALUES (?,?,?)", phones)
    accounts = [(f"account-{i:02d}", "ACC-1001" if i == 1 else f"ACC-{1000+i}", json.dumps([case_ids[i % 4]] + ([case_ids[(i+2)%4]] if i in (1, 3, 5) else []))) for i in range(1, 11)]
    conn.executemany("INSERT INTO accounts VALUES (?,?,?)", accounts)
    documents = [(f"DOC-{1000+i}", f"Synthetic evidence document {i:02d}", json.dumps([case_ids[i % 4]])) for i in range(1, 21)]
    conn.executemany("INSERT INTO documents VALUES (?,?,?)", documents)

    evidence = []
    for i in range(1, 21):
        case_id = case_ids[i % 4]
        ev_type = ["Communication", "Vehicle Record", "Location Record", "Transaction", "Document"][i % 5]
        status = "Confirmed" if i in (1, 5, 9) else "Unreviewed"
        evidence.append((f"EV-{100+i}", ev_type, f"2026-03-{10 + (i % 9):02d}", "Synthetic demo source", f"Synthetic {ev_type.lower()} record {i:02d} requiring human review.", case_id, json.dumps([f"person-{(i%20)+1:02d}", f"vehicle-{(i%10)+1:02d}"]), status))
    conn.executemany("INSERT INTO evidence VALUES (?,?,?,?,?,?,?,?)", evidence)

    relationships = []
    def rel(idx, source, target, kind, ev, case_id, confidence=0.78):
        relationships.append((f"rel-{idx:03d}", source, target, kind, ev, confidence, "Confirmed" if idx in (1, 2, 3) else "Pending Review", case_id))
    rel(1, "person-01", "phone-01", "USES", "EV-101", case_ids[0], .96)
    rel(2, "person-02", "phone-01", "CALLED", "EV-101", case_ids[0], .88)
    rel(3, "person-01", "vehicle-01", "ASSOCIATED_WITH", "EV-102", case_ids[0], .92)
    rel(4, "vehicle-01", "location-01", "SEEN_AT", "EV-102", case_ids[0], .91)
    rel(5, "location-01", "person-02", "VISITED", "EV-103", case_ids[1], .72)
    rel(6, "person-02", "org-01", "ASSOCIATED_WITH", "EV-105", case_ids[0], .79)
    rel(7, "org-01", "account-01", "OWNS", "EV-106", case_ids[0], .76)
    rel(8, "account-01", "person-01", "TRANSFERRED_TO", "EV-106", case_ids[0], .74)
    rel(9, "vehicle-01", "case-003", "RELATED_TO", "EV-109", case_ids[2], .86)
    rel(10, "org-01", "case-003", "ASSOCIATED_WITH", "EV-110", case_ids[2], .77)
    rel(11, "person-03", "org-01", "WORKS_WITH", "EV-111", case_ids[2], .69)
    rel(12, "person-03", "phone-01", "CALLED", "EV-112", case_ids[1], .66)
    rel(13, "document-01", "person-01", "MENTIONS", "EV-113", case_ids[0], .94)
    rel(14, "document-01", "vehicle-01", "MENTIONS", "EV-113", case_ids[0], .94)
    for i in range(15, 61):
        source = f"person-{((i-1)%20)+1:02d}"
        target_type = ["vehicle", "location", "org", "account", "phone"][i % 5]
        target = f"{target_type}-{((i-1)%10)+1:02d}"
        rel(i, source, target, ["ASSOCIATED_WITH", "VISITED", "CALLED", "USED", "MENTIONED_IN"][i % 5], f"EV-{100 + ((i-1)%20)+1}", case_ids[i % 4], .55 + (i % 4) / 10)
    conn.executemany("INSERT INTO relationships VALUES (?,?,?,?,?,?,?,?)", relationships)

    communications = [(f"COM-{i:03d}", f"2026-03-{10 + (i%9):02d}", f"person-{(i%20)+1:02d}", f"person-{((i+1)%20)+1:02d}", f"phone-{(i%10)+1:02d}", case_ids[i%4], f"EV-{100+(i%20)+1}") for i in range(1,31)]
    conn.executemany("INSERT INTO communications VALUES (?,?,?,?,?,?,?)", communications)
    transactions = [(f"TX-{i:03d}", f"2026-03-{10 + (i%9):02d}", 85000 + i*1250, f"account-{(i%10)+1:02d}", f"org-{(i%10)+1:02d}", case_ids[i%4], f"EV-{100+(i%20)+1}") for i in range(1,26)]
    conn.executemany("INSERT INTO transactions VALUES (?,?,?,?,?,?,?)", transactions)

    start = date(2026, 3, 10)
    events = []
    for i in range(1, 31):
        day = start + timedelta(days=i % 9)
        kind = ["Communication", "Vehicle sighting", "Location visit", "Transaction", "Evidence", "Case event"][i % 6]
        events.append((f"timeline-{i:03d}", day.isoformat(), f"{8 + (i%10):02d}:{(i*7)%60:02d}", kind, f"{kind} signal {i:02d}", f"Synthetic timeline event {i:02d} for demonstration.", case_ids[i%4], json.dumps([f"person-{(i%20)+1:02d}", f"vehicle-{(i%10)+1:02d}"])))
    conn.executemany("INSERT INTO timeline_events VALUES (?,?,?,?,?,?,?,?)", events)
    conn.commit()
