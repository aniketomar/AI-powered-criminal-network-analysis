from __future__ import annotations

import json
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

ROOT = Path(__file__).resolve().parents[3]
DB_PATH = Path(__import__('os').environ.get('SENTINEL_DB_PATH', ROOT / 'data' / 'sentinel_graph.db'))

SCHEMA = """
CREATE TABLE IF NOT EXISTS cases (id TEXT PRIMARY KEY, title TEXT NOT NULL, category TEXT, status TEXT, created TEXT, updated TEXT, investigator TEXT, summary TEXT);
CREATE TABLE IF NOT EXISTS people (id TEXT PRIMARY KEY, name TEXT NOT NULL, phone_id TEXT, case_ids TEXT);
CREATE TABLE IF NOT EXISTS vehicles (id TEXT PRIMARY KEY, registration TEXT NOT NULL, case_ids TEXT);
CREATE TABLE IF NOT EXISTS locations (id TEXT PRIMARY KEY, name TEXT NOT NULL, case_ids TEXT);
CREATE TABLE IF NOT EXISTS organizations (id TEXT PRIMARY KEY, name TEXT NOT NULL, case_ids TEXT);
CREATE TABLE IF NOT EXISTS phones (id TEXT PRIMARY KEY, number TEXT NOT NULL, case_ids TEXT);
CREATE TABLE IF NOT EXISTS accounts (id TEXT PRIMARY KEY, label TEXT NOT NULL, case_ids TEXT);
CREATE TABLE IF NOT EXISTS communications (id TEXT PRIMARY KEY, date TEXT, source_id TEXT, target_id TEXT, phone_id TEXT, case_id TEXT, evidence_id TEXT);
CREATE TABLE IF NOT EXISTS transactions (id TEXT PRIMARY KEY, date TEXT, amount INTEGER, source_id TEXT, target_id TEXT, case_id TEXT, evidence_id TEXT);
CREATE TABLE IF NOT EXISTS evidence (id TEXT PRIMARY KEY, type TEXT, date TEXT, source TEXT, description TEXT, case_id TEXT, related_entities TEXT, validation_status TEXT DEFAULT 'Unreviewed');
CREATE TABLE IF NOT EXISTS relationships (id TEXT PRIMARY KEY, source_id TEXT, target_id TEXT, relationship_type TEXT, evidence_id TEXT, confidence REAL, validation_status TEXT DEFAULT 'Pending Review', case_id TEXT);
CREATE TABLE IF NOT EXISTS timeline_events (id TEXT PRIMARY KEY, date TEXT, time TEXT, event_type TEXT, title TEXT, description TEXT, case_id TEXT, entities TEXT);
CREATE TABLE IF NOT EXISTS investigator_reviews (id INTEGER PRIMARY KEY AUTOINCREMENT, target_id TEXT, target_type TEXT, action TEXT, investigator TEXT, note TEXT, timestamp TEXT);
CREATE TABLE IF NOT EXISTS audit_history (id INTEGER PRIMARY KEY AUTOINCREMENT, target_id TEXT, target_type TEXT, action TEXT, investigator TEXT, note TEXT, timestamp TEXT);
CREATE TABLE IF NOT EXISTS documents (id TEXT PRIMARY KEY, label TEXT, case_ids TEXT);
"""


def connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db() -> None:
    with connect() as conn:
        conn.executescript(SCHEMA)
        count = conn.execute("SELECT COUNT(*) AS n FROM cases").fetchone()["n"]
        if count == 0 and os.environ.get("SENTINEL_DEMO_MODE", "0") == "1":
            from app.database.seed import seed
            seed(conn)


def rows(sql: str, params: Iterable[Any] = ()) -> list[dict[str, Any]]:
    with connect() as conn:
        return [dict(row) for row in conn.execute(sql, tuple(params)).fetchall()]


def row(sql: str, params: Iterable[Any] = ()) -> dict[str, Any] | None:
    with connect() as conn:
        result = conn.execute(sql, tuple(params)).fetchone()
        return dict(result) if result else None


def execute(sql: str, params: Iterable[Any] = ()) -> None:
    with connect() as conn:
        conn.execute(sql, tuple(params))
        conn.commit()


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def json_load(value: str | None) -> list[str]:
    try:
        return json.loads(value or "[]")
    except json.JSONDecodeError:
        return []


def json_dump(value: list[str]) -> str:
    return json.dumps(value, separators=(",", ":"))
