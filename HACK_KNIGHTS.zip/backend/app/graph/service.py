from __future__ import annotations

import json
import networkx as nx
from app.database.db import connect, json_load


def build_graph(case_id: str | None = None) -> nx.Graph:
    graph = nx.MultiGraph()
    with connect() as conn:
        tables = [("people", "PERSON", "name"), ("vehicles", "VEHICLE", "registration"), ("locations", "LOCATION", "name"), ("organizations", "ORG", "name"), ("phones", "PHONE", "number"), ("accounts", "ACCOUNT", "label"), ("documents", "DOCUMENT", "label")]
        entity_lookup: dict[str, tuple[str, str, list[str]]] = {}
        for table, kind, label_field in tables:
            for item in conn.execute(f"SELECT * FROM {table}").fetchall():
                memberships = json_load(item["case_ids"])
                entity_lookup[item["id"]] = (item[label_field], kind, memberships)
                if not case_id or case_id in memberships:
                    graph.add_node(item["id"], label=item[label_field], type=kind, cases=memberships)
        query = "SELECT * FROM relationships" + (" WHERE case_id = ?" if case_id else "")
        params = (case_id,) if case_id else ()
        for edge in conn.execute(query, params).fetchall():
            for endpoint in (edge["source_id"], edge["target_id"]):
                if endpoint not in graph and endpoint in entity_lookup:
                    label, kind, memberships = entity_lookup[endpoint]
                    graph.add_node(endpoint, label=label, type=kind, cases=memberships)
            if edge["source_id"] in graph and edge["target_id"] in graph:
                graph.add_edge(edge["source_id"], edge["target_id"], key=edge["id"], id=edge["id"], label=edge["relationship_type"], evidence=edge["evidence_id"], confidence=edge["confidence"], validation_status=edge["validation_status"], case_id=edge["case_id"])
    return graph


def graph_payload(case_id: str | None = None) -> dict:
    graph = build_graph(case_id)
    centrality = nx.degree_centrality(graph) if graph.number_of_nodes() else {}
    return {
        "nodes": [{"id": node, **data, "centrality": round(centrality.get(node, 0), 3)} for node, data in graph.nodes(data=True)],
        "edges": [{"source": source, "target": target, **data} for source, target, _key, data in graph.edges(keys=True, data=True)],
        "stats": {"total_nodes": graph.number_of_nodes(), "total_connections": graph.number_of_edges(), "connected_components": nx.number_connected_components(graph) if graph else 0, "most_connected": sorted(({"id": n, "degree": d} for n, d in graph.degree()), key=lambda x: x["degree"], reverse=True)[:8]},
    }


def shortest_path(source: str, target: str, case_id: str | None = None) -> dict:
    graph = build_graph(case_id)
    try:
        path = nx.shortest_path(graph, source, target)
    except (nx.NetworkXNoPath, nx.NodeNotFound):
        return {"found": False, "path": [], "edges": [], "explanation": "No connected path was found in the selected synthetic graph."}
    edges = []
    for a, b in zip(path, path[1:]):
        edge_data = graph.get_edge_data(a, b) or {}
        data = next(iter(edge_data.values()), {})
        edges.append({"source": a, "target": b, "relationship_type": data.get("label"), "evidence": data.get("evidence"), "confidence": data.get("confidence"), "validation_status": data.get("validation_status"), "reason": "Shared synthetic record in the relationship graph."})
    return {"found": True, "path": path, "edges": edges, "explanation": "Connection path calculated from synthetic relationship metadata."}


def cross_case() -> list[dict]:
    output = []
    with connect() as conn:
        collections = [("people", "PERSON", "name"), ("vehicles", "VEHICLE", "registration"), ("locations", "LOCATION", "name"), ("organizations", "ORG", "name"), ("phones", "PHONE", "number"), ("accounts", "ACCOUNT", "label"), ("documents", "DOCUMENT", "label")]
        for table, kind, label_field in collections:
            for item in conn.execute(f"SELECT id, {label_field}, case_ids FROM {table}").fetchall():
                cases = json_load(item["case_ids"])
                if len(cases) > 1:
                    output.append({"entity_id": item["id"], "entity": item[label_field], "type": kind, "cases": cases, "explanation": "Shared synthetic entity detected between these cases."})
    return output
