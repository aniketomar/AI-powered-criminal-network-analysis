from __future__ import annotations

import csv
import hashlib
import io
import json
import os
from typing import Any

from fastapi import FastAPI, File, HTTPException, Query, UploadFile
from pypdf import PdfReader
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from app.ai.extractor import analyze_text
from app.database.db import connect, execute, init_db, json_load, now_iso, row, rows
from app.graph.service import cross_case, graph_payload, shortest_path

app = FastAPI(title="Sentinel Graph API", version="0.1.0", description="Synthetic investigation intelligence API")
configured_origins = [origin.strip() for origin in os.environ.get("CORS_ORIGINS", "http://localhost:3000,http://localhost:5173").split(",") if origin.strip()]
app.add_middleware(CORSMiddleware, allow_origins=configured_origins, allow_origin_regex=r"^https://[a-z0-9-]+\.manus\.space$", allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
DEMO_MODE = os.environ.get("SENTINEL_DEMO_MODE", "0") == "1"


class TextRequest(BaseModel):
    text: str = Field(min_length=1, max_length=200_000)


class AnalysisEntity(BaseModel):
    type: str = Field(min_length=1, max_length=40)
    value: str = Field(min_length=1, max_length=200)
    confidence: float = Field(default=0.7, ge=0, le=1)


class AnalysisRelationship(BaseModel):
    source: str = Field(min_length=1, max_length=200)
    target: str = Field(min_length=1, max_length=200)
    relationship_type: str = Field(min_length=1, max_length=60)
    evidence_reference: str = Field(default="ANALYSIS-01", max_length=100)
    confidence: float = Field(default=0.7, ge=0, le=1)


class SaveAnalysisRequest(BaseModel):
    case_id: str | None = None
    case_title: str | None = Field(default=None, max_length=200)
    summary: str = Field(default="", max_length=1000)
    entities: list[AnalysisEntity] = Field(default_factory=list, max_length=200)
    relationships: list[AnalysisRelationship] = Field(default_factory=list, max_length=400)


class ValidationRequest(BaseModel):
    target_id: str
    target_type: str = "evidence"
    action: str
    investigator: str = "Demo Investigator"
    note: str = ""


@app.on_event("startup")
def startup() -> None:
    init_db()


@app.get("/api/health")
def health() -> dict[str, Any]:
    init_db()
    return {"status": "ok", "database": str(os.environ.get("SENTINEL_DB_PATH", "data/sentinel_graph.db")), "synthetic_demo": DEMO_MODE}


@app.get("/api/cases")
def get_cases() -> list[dict[str, Any]]:
    init_db()
    output = rows("SELECT * FROM cases ORDER BY updated DESC")
    for item in output:
        item["entities"] = row("SELECT COUNT(*) AS n FROM relationships WHERE case_id = ?", (item["id"],))["n"]
        item["relationships"] = item["entities"]
    return output


@app.get("/api/cases/{case_id}")
def get_case(case_id: str) -> dict[str, Any]:
    item = row("SELECT * FROM cases WHERE id = ?", (case_id,))
    if not item: raise HTTPException(404, "Case not found")
    item["evidence"] = rows("SELECT * FROM evidence WHERE case_id = ?", (case_id,))
    item["network"] = graph_payload(case_id)
    return item


@app.get("/api/entities")
def get_entities(case_id: str | None = None) -> list[dict[str, Any]]:
    init_db()
    collections = [("people", "PERSON", "name"), ("vehicles", "VEHICLE", "registration"), ("locations", "LOCATION", "name"), ("organizations", "ORG", "name"), ("phones", "PHONE", "number"), ("accounts", "ACCOUNT", "label"), ("documents", "DOCUMENT", "label")]
    output = []
    for table, kind, label in collections:
        for item in rows(f"SELECT * FROM {table}"):
            memberships = json_load(item.get("case_ids"))
            if case_id and case_id not in memberships: continue
            output.append({"id": item["id"], "label": item[label], "type": kind, "cases": memberships})
    return output


@app.get("/api/entities/{entity_id}")
def get_entity(entity_id: str) -> dict[str, Any]:
    for item in get_entities():
        if item["id"] == entity_id:
            item["relationships"] = rows("SELECT * FROM relationships WHERE source_id = ? OR target_id = ?", (entity_id, entity_id))
            evidence_ids = sorted({edge.get("evidence_id") or edge.get("evidence") for edge in item["relationships"] if edge.get("evidence_id") or edge.get("evidence")})
            item["evidence"] = [record for evidence_id in evidence_ids if (record := row("SELECT * FROM evidence WHERE id = ?", (evidence_id,)))]
            item["related_cases"] = sorted({case_id for edge in item["relationships"] if (case_id := edge.get("case_id"))})
            return item
    raise HTTPException(404, "Entity not found")


@app.get("/api/relationships")
def get_relationships(case_id: str | None = None) -> list[dict[str, Any]]:
    return rows("SELECT * FROM relationships" + (" WHERE case_id = ?" if case_id else ""), (case_id,) if case_id else ())


@app.get("/api/evidence")
def get_evidence(case_id: str | None = None, status: str | None = None) -> list[dict[str, Any]]:
    query = "SELECT * FROM evidence WHERE 1=1"
    params: list[str] = []
    if case_id: query += " AND case_id = ?"; params.append(case_id)
    if status: query += " AND validation_status = ?"; params.append(status)
    output = rows(query + " ORDER BY date DESC", params)
    for item in output: item["related_entities"] = json_load(item.get("related_entities"))
    return output


@app.get("/api/network/{case_id}")
def get_network(case_id: str) -> dict[str, Any]:
    if not row("SELECT id FROM cases WHERE id = ?", (case_id,)): raise HTTPException(404, "Case not found")
    return graph_payload(case_id)


@app.get("/api/timeline/{case_id}")
def get_timeline(case_id: str, event_type: str | None = None, entity: str | None = None, start_date: str | None = None, end_date: str | None = None) -> list[dict[str, Any]]:
    query = "SELECT * FROM timeline_events WHERE case_id = ?"
    params: list[str] = [case_id]
    if event_type: query += " AND event_type = ?"; params.append(event_type)
    if start_date: query += " AND date >= ?"; params.append(start_date)
    if end_date: query += " AND date <= ?"; params.append(end_date)
    output = rows(query + " ORDER BY date, time", params)
    for item in output: item["entities"] = json_load(item.get("entities"))
    if entity: output = [item for item in output if entity in item["entities"]]
    return output


@app.get("/api/cross-case")
def get_cross_case() -> list[dict[str, Any]]:
    results = cross_case()
    for item in results:
        item["evidence"] = rows("SELECT DISTINCT e.* FROM evidence e JOIN relationships r ON r.evidence_id = e.id WHERE (r.source_id = ? OR r.target_id = ?) AND r.case_id IN (?, ?)", (item["entity_id"], item["entity_id"], item["cases"][0], item["cases"][1]))
    return results


@app.get("/api/search")
def search(q: str = Query(min_length=2)) -> dict[str, Any]:
    needle = f"%{q}%"
    results = []
    for table, kind, label in [("people", "Person", "name"), ("vehicles", "Vehicle", "registration"), ("locations", "Location", "name"), ("organizations", "Organization", "name"), ("phones", "Phone", "number"), ("accounts", "Account", "label"), ("cases", "Case", "id"), ("evidence", "Evidence", "id")]:
        for item in rows(f"SELECT * FROM {table} WHERE {label} LIKE ? LIMIT 20", (needle,)):
            results.append({"kind": kind, "label": item[label], "id": item["id"], "meta": item.get("case_id") or item.get("title") or "Stored record"})
    return {"query": q, "results": results}


@app.get("/api/path")
def get_path(source: str, target: str, case_id: str | None = None) -> dict[str, Any]:
    return shortest_path(source, target, case_id)


@app.post("/api/analyze-text")
def analyze(request: TextRequest) -> dict[str, Any]:
    return analyze_text(request.text)


@app.post("/api/analyze-text/save")
def save_analysis(request: SaveAnalysisRequest) -> dict[str, Any]:
    try:
        normalized_entities = [(entity, _normalize_entity_type(entity.type)) for entity in request.entities]
    except ValueError as error:
        raise HTTPException(400, str(error)) from error
    case_id = request.case_id.strip() if request.case_id else ""
    if case_id and not row("SELECT id FROM cases WHERE id = ?", (case_id,)):
        raise HTTPException(404, "Case not found")
    if not case_id:
        if not request.case_title or not request.case_title.strip():
            raise HTTPException(400, "Select an existing case or provide a case title")
        case_id = f"CASE-AI-{hashlib.sha1(request.case_title.strip().encode()).hexdigest()[:10].upper()}"
        timestamp = now_iso()
        execute("INSERT OR IGNORE INTO cases (id,title,category,status,created,updated,investigator,summary) VALUES (?,?,?,?,?,?,?,?)", (case_id, request.case_title.strip(), "AI Analysis", "Active", timestamp, timestamp, "Unassigned", request.summary or "AI analysis pending investigator review."))
    invalid_case_entities = [entity.value for entity, entity_type in normalized_entities if entity_type == "CASE" and entity.value.strip() != case_id]
    if invalid_case_entities:
        raise HTTPException(400, f"CASE entities must reference the selected case: {', '.join(invalid_case_entities)}")
    evidence_id = f"AI-EVIDENCE-{hashlib.sha1(f'{case_id}:{request.summary}'.encode()).hexdigest()[:12].upper()}"
    values = [entity.value.strip() for entity in request.entities]
    if not row("SELECT id FROM evidence WHERE id = ?", (evidence_id,)):
        execute("INSERT INTO evidence (id,type,date,source,description,case_id,related_entities,validation_status) VALUES (?,?,?,?,?,?,?,?)", (evidence_id, "Gemini analysis", now_iso()[:10], "Gemini Text Analysis", request.summary or "AI-generated candidate analysis", case_id, json.dumps(values), "Unreviewed"))
    entity_ids: dict[str, str] = {}
    saved_entities = 0
    for entity, entity_type in normalized_entities:
        entity_id = _upsert_entity(entity_type, entity.value, case_id)
        if entity_id:
            entity_ids[entity.value.strip().lower()] = entity_id
            saved_entities += 1
    saved_relationships = 0
    skipped_relationships = 0
    for relationship in request.relationships:
        source_id = entity_ids.get(relationship.source.strip().lower())
        target_id = entity_ids.get(relationship.target.strip().lower())
        if not source_id or not target_id or source_id == target_id:
            skipped_relationships += 1
            continue
        duplicate = row("SELECT id FROM relationships WHERE case_id = ? AND source_id = ? AND target_id = ? AND relationship_type = ?", (case_id, source_id, target_id, relationship.relationship_type.upper()))
        if duplicate:
            continue
        relationship_id = f"AI-REL-{hashlib.sha1(f'{case_id}:{source_id}:{target_id}:{relationship.relationship_type.upper()}'.encode()).hexdigest()[:12].upper()}"
        execute("INSERT INTO relationships (id,source_id,target_id,relationship_type,evidence_id,confidence,validation_status,case_id) VALUES (?,?,?,?,?,?,?,?)", (relationship_id, source_id, target_id, relationship.relationship_type.upper(), evidence_id, relationship.confidence, "Pending Review", case_id))
        saved_relationships += 1
    return {"ok": True, "case_id": case_id, "evidence_id": evidence_id, "saved_entities": saved_entities, "saved_relationships": saved_relationships, "skipped_relationships": skipped_relationships, "validation_status": "Pending Review"}


@app.post("/api/validate")
def validate(request: ValidationRequest) -> dict[str, Any]:
    if request.action not in {"Confirm", "Reject", "Review later", "Add Note"}: raise HTTPException(400, "Unsupported validation action")
    if request.target_type.lower() == "evidence":
        status = {"Confirm": "Confirmed", "Reject": "Rejected", "Review later": "Unreviewed", "Add Note": "Unreviewed"}[request.action]
        execute("UPDATE evidence SET validation_status = ? WHERE id = ?", (status, request.target_id))
    elif request.target_type.lower() == "relationship":
        status = "Confirmed" if request.action == "Confirm" else "Rejected" if request.action == "Reject" else "Pending Review"
        execute("UPDATE relationships SET validation_status = ? WHERE id = ?", (status, request.target_id))
    timestamp = now_iso()
    execute("INSERT INTO investigator_reviews (target_id,target_type,action,investigator,note,timestamp) VALUES (?,?,?,?,?,?)", (request.target_id, request.target_type, request.action, request.investigator, request.note, timestamp))
    execute("INSERT INTO audit_history (target_id,target_type,action,investigator,note,timestamp) VALUES (?,?,?,?,?,?)", (request.target_id, request.target_type, request.action, request.investigator, request.note, timestamp))
    return {"ok": True, "target_id": request.target_id, "action": request.action, "timestamp": timestamp}


ENTITY_TABLES = {
    "PERSON": ("people", "name"),
    "VEHICLE": ("vehicles", "registration"),
    "LOCATION": ("locations", "name"),
    "ORGANIZATION": ("organizations", "name"),
    "ORG": ("organizations", "name"),
    "PHONE": ("phones", "number"),
    "ACCOUNT": ("accounts", "label"),
    "DOCUMENT": ("documents", "label"),
}
ENTITY_TYPE_ALIASES = {"ORGANISATION": "ORGANIZATION", "ORG": "ORGANIZATION", "CASE_ID": "CASE", "PHONE_NUMBER": "PHONE", "VEHICLE_REGISTRATION": "VEHICLE"}


def _normalize_entity_type(value: str) -> str:
    normalized = value.strip().upper().replace("-", "_").replace(" ", "_")
    normalized = ENTITY_TYPE_ALIASES.get(normalized, normalized)
    if normalized != "CASE" and normalized not in ENTITY_TABLES:
        raise ValueError(f"Unsupported entity type: {value}")
    return normalized



def _ensure_case(case_id: str, source: str) -> str:
    case_id = case_id.strip() or "CASE-IMPORT-001"
    if not row("SELECT id FROM cases WHERE id = ?", (case_id,)):
        timestamp = now_iso()
        execute("INSERT INTO cases (id,title,category,status,created,updated,investigator,summary) VALUES (?,?,?,?,?,?,?,?)", (case_id, f"Imported investigation · {source}", "Imported", "Active", timestamp, timestamp, "Unassigned", "Imported records pending investigator review."))
    return case_id


def _upsert_entity(entity_type: str, value: str, case_id: str) -> str | None:
    normalized_type = _normalize_entity_type(entity_type)
    if normalized_type == "CASE":
        return case_id if value.strip() == case_id else None
    mapping = ENTITY_TABLES.get(normalized_type)
    value = value.strip()
    if not mapping or not value:
        return None
    table, label = mapping
    existing = row(f"SELECT id, case_ids FROM {table} WHERE lower({label}) = lower(?) LIMIT 1", (value,))
    if existing:
        memberships = json_load(existing.get("case_ids"))
        if case_id not in memberships:
            memberships.append(case_id)
            execute(f"UPDATE {table} SET case_ids = ? WHERE id = ?", (json.dumps(memberships), existing["id"]))
        return existing["id"]
    entity_id = f"IMP-{normalized_type}-{hashlib.sha1(value.lower().encode()).hexdigest()[:12]}"
    execute(f"INSERT OR IGNORE INTO {table} (id,{label},case_ids) VALUES (?,?,?)", (entity_id, value, json.dumps([case_id])))
    return entity_id


def _persist_analysis_links(analysis: dict[str, Any], evidence_id: str, case_id: str) -> None:
    entity_ids: dict[str, str] = {}
    for item in analysis.get("entities", []):
        entity_id = _upsert_entity(str(item.get("type", "")), str(item.get("value", "")), case_id)
        if entity_id:
            entity_ids[str(item.get("value", "")).strip().lower()] = entity_id
    for index, relation in enumerate(analysis.get("relationships", []), 1):
        source_id = entity_ids.get(str(relation.get("source", "")).strip().lower())
        target_id = entity_ids.get(str(relation.get("target", "")).strip().lower())
        if not source_id or not target_id:
            continue
        relationship_id = f"IMP-REL-{hashlib.sha1(f'{evidence_id}:{source_id}:{target_id}:{index}'.encode()).hexdigest()[:12]}"
        execute("INSERT OR IGNORE INTO relationships (id,source_id,target_id,relationship_type,evidence_id,confidence,validation_status,case_id) VALUES (?,?,?,?,?,?,?,?)", (relationship_id, source_id, target_id, str(relation.get("relationship_type") or "ASSOCIATED_WITH"), evidence_id, float(relation.get("confidence", 0.7)), "Pending Review", case_id))


def _ingest_records(records: list[dict[str, Any]], filename: str) -> int:
    case = row("SELECT id FROM cases ORDER BY id LIMIT 1")
    case_id = _ensure_case(str(case["id"]) if case else "CASE-IMPORT-001", filename)
    imported = 0
    for index, record in enumerate(records[:500], 1):
        evidence_id = str(record.get("id") or record.get("evidence_id") or f"IMP-{abs(hash(filename)) % 10000:04d}-{index:03d}")
        description = str(record.get("description") or json.dumps(record, ensure_ascii=False))
        if not row("SELECT id FROM evidence WHERE id = ?", (evidence_id,)):
            execute("INSERT INTO evidence (id,type,date,source,description,case_id,related_entities,validation_status) VALUES (?,?,?,?,?,?,?,?)", (evidence_id, "Imported record", "2026-03-18", filename, description[:2000], str(record.get("case_id") or case_id), json.dumps([]), "Unreviewed"))
            imported_case = _ensure_case(str(record.get("case_id") or case_id), filename)
            execute("INSERT OR IGNORE INTO documents (id,label,case_ids) VALUES (?,?,?)", (evidence_id, f"Imported record · {filename}", json.dumps([imported_case])))
            execute("INSERT OR IGNORE INTO timeline_events (id,date,time,event_type,title,description,case_id,entities) VALUES (?,?,?,?,?,?,?,?)", (f"{evidence_id}-TIMELINE", "2026-03-18", "12:00", "Evidence", f"Imported record: {filename}", description[:500], imported_case, json.dumps([evidence_id])))
            imported += 1
    return imported


def _persist_text_import(filename: str, text: str, analysis: dict[str, Any]) -> str:
    evidence_id = f"IMP-TEXT-{abs(hash((filename, text))) % 100000:05d}"
    entities = [item["value"] for item in analysis.get("entities", [])]
    case_id = _ensure_case("CASE-IMPORT-001", filename)
    if not row("SELECT id FROM evidence WHERE id = ?", (evidence_id,)):
        execute("INSERT INTO evidence (id,type,date,source,description,case_id,related_entities,validation_status) VALUES (?,?,?,?,?,?,?,?)", (evidence_id, "Imported text", "2026-03-18", filename, text[:2000], case_id, json.dumps(entities), "Unreviewed"))
        execute("INSERT OR IGNORE INTO documents (id,label,case_ids) VALUES (?,?,?)", (evidence_id, f"Imported text · {filename}", json.dumps([case_id])))
        execute("INSERT INTO timeline_events (id,date,time,event_type,title,description,case_id,entities) VALUES (?,?,?,?,?,?,?,?)", (f"{evidence_id}-TIMELINE", "2026-03-18", "12:00", "Evidence", f"Imported text analyzed: {filename}", "Imported text persisted for investigator review.", case_id, json.dumps(entities)))
        _persist_analysis_links(analysis, evidence_id, case_id)
    return evidence_id


@app.post("/api/import")
async def import_file(file: UploadFile = File(...)) -> dict[str, Any]:
    content = await file.read()
    if len(content) > 5_000_000: raise HTTPException(413, "File exceeds the 5 MB demo limit")
    name = (file.filename or "").lower()
    if not name.endswith((".txt", ".csv", ".json", ".pdf")): raise HTTPException(400, "Supported file types: TXT, CSV, JSON, PDF")
    if name.endswith(".txt"):
        text = content.decode("utf-8", errors="replace")
        if not text.strip(): raise HTTPException(400, "TXT file is empty")
        analysis = analyze_text(text)
        imported_id = _persist_text_import(file.filename or "import.txt", text, analysis)
        return {"filename": file.filename, "kind": "text", "analysis": analysis, "imported_evidence_id": imported_id, "message": "TXT analyzed and persisted as unreviewed evidence."}
    if name.endswith(".csv"):
        decoded = content.decode("utf-8", errors="replace")
        records = list(csv.DictReader(io.StringIO(decoded)))
        if not records: raise HTTPException(400, "CSV must contain a header row and at least one record")
        imported = _ingest_records(records, file.filename or "import.csv")
        return {"filename": file.filename, "kind": "csv", "records_preview": records[:25], "record_count": len(records), "imported_count": imported, "message": "CSV parsed and imported as unreviewed evidence."}
    if name.endswith(".json"):
        try: parsed = json.loads(content.decode("utf-8"))
        except json.JSONDecodeError as error: raise HTTPException(400, f"Invalid JSON: {error.msg}") from error
        records = parsed if isinstance(parsed, list) else [parsed]
        if not records or not all(isinstance(record, dict) for record in records): raise HTTPException(400, "JSON must contain an object or an array of objects")
        imported = _ingest_records(records, file.filename or "import.json")
        return {"filename": file.filename, "kind": "json", "records_preview": records[:25], "record_count": len(records), "imported_count": imported, "message": "JSON parsed and imported as unreviewed evidence."}
    try: reader = PdfReader(io.BytesIO(content))
    except Exception as error: raise HTTPException(400, "Invalid PDF file") from error
    text = "\n".join(page.extract_text() or "" for page in reader.pages)
    if not text.strip(): raise HTTPException(400, "PDF contains no extractable text")
    analysis = analyze_text(text)
    imported_id = _persist_text_import(file.filename or "import.pdf", text, analysis)
    return {"filename": file.filename, "kind": "pdf", "page_count": len(reader.pages), "analysis": analysis, "imported_evidence_id": imported_id, "message": "PDF text extracted and persisted as unreviewed evidence."}


@app.get("/api/dashboard/stats")
def dashboard_stats() -> dict[str, Any]:
    init_db()
    with connect() as conn:
        active = conn.execute("SELECT COUNT(*) AS n FROM cases WHERE status = 'Active'").fetchone()["n"]
        evidence_count = conn.execute("SELECT COUNT(*) AS n FROM evidence").fetchone()["n"]
        pending = conn.execute("SELECT COUNT(*) AS n FROM evidence WHERE validation_status IN ('Unreviewed','Pending Validation')").fetchone()["n"]
        relationships = conn.execute("SELECT COUNT(*) AS n FROM relationships").fetchone()["n"]
    entity_count = len(get_entities())
    return {"active_cases": active, "connected_entities": entity_count, "relationships": relationships, "cross_case_links": len(get_cross_case()), "pending_validation": pending, "evidence": evidence_count, "synthetic_demo": DEMO_MODE}
