from __future__ import annotations

import json
import os
import re
from typing import Any

from google import genai
from google.genai import types

PATTERNS = [
    ("PHONE", re.compile(r"(?:phone\s*)?(\+?91[-\s]?\d{10}|\d{10})\b", re.I)),
    ("VEHICLE", re.compile(r"\b[A-Z]{2}\d{2}[A-Z]{2}\d{4}\b", re.I)),
    ("DATE", re.compile(r"\b\d{1,2}\s(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s\d{4}\b", re.I)),
    ("MONEY", re.compile(r"₹\s?[\d,]+|\b(?:INR|Rs\.?)\s?[\d,]+", re.I)),
    ("ACCOUNT", re.compile(r"\bACC[-\s]?\d{4}\b", re.I)),
    ("CASE ID", re.compile(r"\bCASE-\d{4}-\d{3}\b", re.I)),
    ("DOCUMENT", re.compile(r"\bDOC-\d{4}\b", re.I)),
    ("LOCATION", re.compile(r"\b(?:Sector\s+[A-Z]|[A-Z][a-z]+\s(?:Transit Yard|Nagar|District))\b")),
    ("ORGANIZATION", re.compile(r"\b[A-Z][a-z]+\s(?:Freight|Logistics|Industries|Co\.)\b")),
    ("PERSON", re.compile(r"\b(?:Person\s+)?([A-Z][a-z]+\s[A-Z][a-z]+)\b")),
]

GEMINI_MODEL = "gemini-3.5-flash-lite"
GEMINI_SCHEMA = {
    "type": "OBJECT",
    "properties": {
        "summary": {"type": "STRING"},
        "entities": {
            "type": "ARRAY",
            "items": {
                "type": "OBJECT",
                "properties": {
                    "type": {"type": "STRING"},
                    "value": {"type": "STRING"},
                    "confidence": {"type": "NUMBER"},
                },
                "required": ["type", "value", "confidence"],
            },
        },
        "relationships": {
            "type": "ARRAY",
            "items": {
                "type": "OBJECT",
                "properties": {
                    "source": {"type": "STRING"},
                    "target": {"type": "STRING"},
                    "relationship_type": {"type": "STRING"},
                    "evidence_reference": {"type": "STRING"},
                    "confidence": {"type": "NUMBER"},
                },
                "required": ["source", "target", "relationship_type", "confidence"],
            },
        },
    },
    "required": ["summary", "entities", "relationships"],
}


def extract_entities(text: str) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for entity_type, pattern in PATTERNS:
        for match in pattern.finditer(text):
            value = (match.group(1) if match.lastindex else match.group(0)).strip().rstrip(".")
            key = (entity_type, value.lower())
            if len(value) > 2 and key not in seen:
                seen.add(key)
                results.append({"type": entity_type, "value": value, "confidence": 0.96 if entity_type in {"PERSON", "VEHICLE"} else 0.91, "source": "rule-based-local"})
    return results


def extract_relationships(text: str, entities: list[dict[str, Any]]) -> list[dict[str, Any]]:
    values = {item["value"]: item for item in entities}
    relationships = []

    def add(source: str, target: str, kind: str, evidence: str = "TEXT-01", confidence: float = .78):
        if source in values and target in values:
            relationships.append({"source": source, "target": target, "relationship_type": kind, "evidence_reference": evidence, "confidence": confidence, "validation_status": "Pending Review"})

    people = [item["value"] for item in entities if item["type"] == "PERSON"]
    vehicles = [item["value"] for item in entities if item["type"] == "VEHICLE"]
    locations = [item["value"] for item in entities if item["type"] == "LOCATION"]
    accounts = [item["value"] for item in entities if item["type"] == "ACCOUNT"]
    phones = [item["value"] for item in entities if item["type"] == "PHONE"]
    money = [item["value"] for item in entities if item["type"] == "MONEY"]
    orgs = [item["value"] for item in entities if item["type"] == "ORGANIZATION"]
    if len(people) >= 2: add(people[0], people[1], "CONTACTED", confidence=.82)
    if people and phones: add(people[0], phones[0], "USED", confidence=.86)
    if vehicles and locations: add(vehicles[0], locations[0], "SEEN_AT", confidence=.88)
    if accounts and money: add(accounts[0], money[0], "TRANSFERRED_TO", confidence=.72)
    if orgs and accounts: add(orgs[0], accounts[0], "ASSOCIATED_WITH", confidence=.74)
    return relationships


def _fallback_analysis(text: str) -> dict[str, Any]:
    entities = extract_entities(text)
    relationships = extract_relationships(text, entities)
    return {"summary": "Rule-based local analysis; Gemini was unavailable.", "analysis_source": "rule-based-local", "entities": entities, "relationships": relationships, "evidence": [{"id": "TEXT-01", "type": "Document", "description": "Pasted synthetic investigation text", "validation_status": "Unreviewed"}]}


def _normalize_gemini_analysis(payload: dict[str, Any]) -> dict[str, Any]:
    entities = []
    for item in payload.get("entities", []):
        if not isinstance(item, dict) or not item.get("type") or not item.get("value"):
            continue
        entities.append({
            "type": str(item["type"]).upper()[:40],
            "value": str(item["value"]).strip()[:200],
            "confidence": max(0.0, min(1.0, float(item.get("confidence", 0.7)))),
            "source": "gemini",
        })
    relationships = []
    for item in payload.get("relationships", []):
        if not isinstance(item, dict) or not item.get("source") or not item.get("target") or not item.get("relationship_type"):
            continue
        relationships.append({
            "source": str(item["source"]).strip()[:200],
            "target": str(item["target"]).strip()[:200],
            "relationship_type": str(item["relationship_type"]).upper()[:60],
            "evidence_reference": str(item.get("evidence_reference") or "GEMINI-01")[:100],
            "confidence": max(0.0, min(1.0, float(item.get("confidence", 0.7)))),
            "validation_status": "Pending Review",
        })
    return {
        "summary": str(payload.get("summary") or "Gemini evidence summary unavailable.")[:1000],
        "analysis_source": "gemini",
        "entities": entities,
        "relationships": relationships,
        "evidence": [{"id": "TEXT-01", "type": "Document", "description": "Pasted synthetic investigation text", "validation_status": "Unreviewed"}],
    }


def _gemini_analysis(text: str) -> dict[str, Any] | None:
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        return None
    try:
        client = genai.Client(api_key=api_key, http_options=types.HttpOptions(timeout=10_000))
        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=(
                "Analyze the following investigation evidence. Produce a concise neutral summary and suggestions "
                "for entities and relationships. These are hypotheses for investigator review, never findings of guilt.\n\n"
                f"EVIDENCE:\n{text}"
            ),
            config=types.GenerateContentConfig(
                temperature=0.1,
                max_output_tokens=1200,
                response_mime_type="application/json",
                response_schema=GEMINI_SCHEMA,
            ),
        )
        raw = response.text or ""
        payload = json.loads(raw.strip().removeprefix("```json").removesuffix("```").strip())
        if not isinstance(payload, dict):
            return None
        return _normalize_gemini_analysis(payload)
    except Exception:
        return None


def analyze_text(text: str) -> dict[str, Any]:
    return _gemini_analysis(text) or _fallback_analysis(text)
