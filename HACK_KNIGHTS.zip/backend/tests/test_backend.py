import os
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

DB = Path(__file__).parent / "test_sentinel.db"
os.environ["SENTINEL_DB_PATH"] = str(DB)
os.environ["SENTINEL_DEMO_MODE"] = "1"

from app.database.db import init_db
import app.ai.extractor as extractor
from app.ai.extractor import analyze_text
from app.graph.service import cross_case, graph_payload, shortest_path
from app.main import app


@pytest.fixture(scope="module", autouse=True)
def database():
    if DB.exists(): DB.unlink()
    init_db()
    yield
    if DB.exists(): DB.unlink()


def test_seed_counts_and_graph():
    payload = graph_payload()
    assert len(payload["nodes"]) >= 80
    assert len(payload["edges"]) >= 50
    assert payload["stats"]["total_connections"] >= 50


def test_text_extraction_and_pending_relationships(monkeypatch):
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    result = analyze_text("On 12 March 2026, Arjun Sharma contacted Ravi Verma using phone 9000000001. Vehicle UP16AB1234 was seen near Sector X Transit Yard. Transfer ₹85,000 to ACC-1001.")
    types = {item["type"] for item in result["entities"]}
    assert {"PERSON", "PHONE", "VEHICLE", "LOCATION", "MONEY", "ACCOUNT"}.issubset(types)
    assert result["relationships"]
    assert all(item["validation_status"] == "Pending Review" for item in result["relationships"])


def test_gemini_analysis_is_used_when_configured(monkeypatch):
    class FakeResponse:
        text = '{"summary":"Two people and one account are mentioned.","entities":[{"type":"PERSON","value":"Arjun Sharma","confidence":0.94}],"relationships":[{"source":"Arjun Sharma","target":"ACC-1001","relationship_type":"TRANSFERRED_TO","confidence":0.81}]}'

    class FakeModels:
        def generate_content(self, **kwargs):
            assert kwargs["model"] == "gemini-3.5-flash-lite"
            assert kwargs["config"].response_mime_type == "application/json"
            return FakeResponse()

    class FakeClient:
        models = FakeModels()

    monkeypatch.setenv("GEMINI_API_KEY", "test-key")
    monkeypatch.setattr(extractor.genai, "Client", lambda **kwargs: FakeClient())
    result = analyze_text("Arjun Sharma transferred funds to ACC-1001.")
    assert result["analysis_source"] == "gemini"
    assert result["summary"].startswith("Two people")
    assert result["relationships"][0]["validation_status"] == "Pending Review"


def test_shortest_path_and_cross_case():
    path = shortest_path("person-01", "account-01")
    assert path["found"]
    assert len(path["edges"]) >= 1
    shared = cross_case()
    assert any(item["entity"] == "UP16 AB 1234" for item in shared)


def test_api_endpoints_and_validation():
    client = TestClient(app)
    assert client.get("/api/health").status_code == 200
    assert len(client.get("/api/cases").json()) == 4
    assert client.get("/api/dashboard/stats").json()["synthetic_demo"] is True
    search = client.get("/api/search", params={"q": "UP16"})
    assert search.status_code == 200 and search.json()["results"]
    response = client.post("/api/validate", json={"target_id": "EV-102", "target_type": "evidence", "action": "Confirm", "investigator": "Demo Investigator", "note": "Reviewed synthetic record."})
    assert response.status_code == 200


def test_imports_persist_and_validate_input():
    client = TestClient(app)
    text_response = client.post("/api/import", files={"file": ("network.txt", b"Arjun Sharma contacted Ravi Verma using phone 9000000001.", "text/plain")})
    assert text_response.status_code == 200
    imported_id = text_response.json()["imported_evidence_id"]
    assert client.get("/api/evidence").json()
    assert any(item["id"] == imported_id for item in client.get("/api/evidence").json())

    csv_response = client.post("/api/import", files={"file": ("records.csv", b"id,description\nCSV-001,Imported CSV record\n", "text/csv")})
    assert csv_response.status_code == 200
    assert csv_response.json()["imported_count"] == 1

    json_response = client.post("/api/import", files={"file": ("records.json", b'[{"id":"JSON-001","description":"Imported JSON record"}]', "application/json")})
    assert json_response.status_code == 200
    assert json_response.json()["imported_count"] == 1

    invalid_json = client.post("/api/import", files={"file": ("broken.json", b"{not-json", "application/json")})
    assert invalid_json.status_code == 400

    invalid_pdf = client.post("/api/import", files={"file": ("broken.pdf", b"not-a-pdf", "application/pdf")})
    assert invalid_pdf.status_code == 400


def test_save_analysis_persists_pending_graph_records_and_avoids_duplicates():
    client = TestClient(app)
    payload = {
        "case_id": "CASE-2026-001",
        "summary": "Synthetic Gemini candidate summary.",
        "entities": [
            {"type": "PERSON", "value": "Saved Analyst Person", "confidence": 0.91},
            {"type": "PHONE", "value": "+91 98888 12345", "confidence": 0.88},
            {"type": "VEHICLE", "value": "UP99 ZZ 1234", "confidence": 0.86},
        ],
        "relationships": [{"source": "Saved Analyst Person", "target": "+91 98888 12345", "relationship_type": "USES", "confidence": 0.84}, {"source": "Saved Analyst Person", "target": "UP99 ZZ 1234", "relationship_type": "ASSOCIATED_WITH", "confidence": 0.84}, {"source": "Unknown Endpoint", "target": "+91 98888 12345", "relationship_type": "USES", "confidence": 0.84}],
    }
    first = client.post("/api/analyze-text/save", json=payload)
    assert first.status_code == 200
    assert first.json()["saved_relationships"] == 2
    assert first.json()["skipped_relationships"] == 1
    repeat = client.post("/api/analyze-text/save", json=payload)
    assert repeat.status_code == 200
    assert repeat.json()["saved_relationships"] == 0
    assert repeat.json()["validation_status"] == "Pending Review"
    graph = client.get("/api/network/CASE-2026-001").json()
    node_ids = {node["id"] for node in graph["nodes"]}
    assert any(node["label"] == "Saved Analyst Person" for node in graph["nodes"])
    assert any(node["label"] == "UP99 ZZ 1234" and node["type"] == "VEHICLE" for node in graph["nodes"])
    assert any(edge["label"] == "USES" and edge["validation_status"] == "Pending Review" for edge in graph["edges"])
    assert any(edge["label"] == "ASSOCIATED_WITH" for edge in graph["edges"])
    assert len(node_ids) >= 2
    created = client.post("/api/analyze-text/save", json={"case_title": "AI Created Case", "summary": "New synthetic case", "entities": [{"type": "PERSON", "value": "New Case Person", "confidence": 0.8}], "relationships": []})
    assert created.status_code == 200
    assert any(item["id"] == created.json()["case_id"] for item in client.get("/api/cases").json())
    unsupported = client.post("/api/analyze-text/save", json={"case_id": "CASE-2026-001", "entities": [{"type": "ALIEN", "value": "Unsupported", "confidence": 0.5}], "relationships": []})
    assert unsupported.status_code == 400
