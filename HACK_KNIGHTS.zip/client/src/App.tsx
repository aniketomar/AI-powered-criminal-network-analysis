import { useEffect, useMemo, useRef, useState } from "react";
import {
  Activity,
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  Bell,
  BookOpen,
  BrainCircuit,
  CalendarDays,
  Check,
  ChevronDown,
  ChevronRight,
  CircleAlert,
  ClipboardCheck,
  Clock3,
  Crosshair,
  Database,
  Download,
  FileSearch,
  Filter,
  FolderOpen,
  GitBranch,
  Globe2,
  Hexagon,
  History,
  LayoutDashboard,
  Link2,
  ListFilter,
  Menu,
  MessageSquareText,
  Network,
  PanelLeftClose,
  PanelLeftOpen,
  Radar,
  RefreshCw,
  Search,
  Send,
  ShieldCheck,
  Sparkles,
  Target,
  TimerReset,
  UserRound,
  UsersRound,
  X,
  Zap,
} from "lucide-react";
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import {
  activityChart,
  cases,
  connectedNodes,
  entityBreakdown,
  entityTypeStyles,
  evidence as evidenceData,
  findNode,
  getStatusTone,
  graphEdges,
  graphNodes,
  insightSeeds,
  navItems,
  parseSyntheticText,
  sampleText,
  searchCorpus,
  timeline,
  type CaseRecord,
  type GraphNode,
  type GraphEdge,
  type ViewKey,
} from "./lib/demoData";
import { analyzeTextWithBackend, getCases, getCrossCase, getDashboardStats, getEvidence, getHealth, getNetwork, getPath, getTimeline, saveAnalysis, searchRecords, validateEvidence, type AnalysisResponse, type ApiCase, type ApiCrossCase, type ApiEvidence, type ApiGraph, type ApiSearchResult, type ApiTimelineEvent, type DashboardStats, type ApiPath } from "./lib/api";
import { graphLabelLines, layoutGraph } from "./lib/networkLayout";

function apiCaseToRecord(item: ApiCase): CaseRecord {
  return { id: item.id, title: item.title, category: item.category || "Synthetic investigation", status: item.status as CaseRecord["status"], created: item.created, updated: item.updated, entities: item.entities ?? 0, relationships: item.relationships ?? 0, investigator: item.investigator, summary: item.summary };
}

function apiGraphToLocal(graph: ApiGraph): { nodes: GraphNode[]; edges: GraphEdge[] } {
  const nodes = graph.nodes.map((node, index) => ({ id: node.id, label: node.label, type: (node.type === "ORG" ? "ORG" : node.type) as GraphNode["type"], x: 100 + (index % 5) * 170, y: 100 + Math.floor(index / 5) * 120, cases: node.cases || [], detail: `Live synthetic ${node.type.toLowerCase()} record from the SQLite relationship graph.` }));
  const edges = graph.edges.map((edge) => ({ id: edge.id, source: edge.source, target: edge.target, label: edge.label, evidence: edge.evidence, strength: edge.confidence >= .85 ? "Strong" : edge.confidence >= .7 ? "Moderate" : "Emerging" } as GraphEdge));
  return { nodes, edges };
}

function apiEvidenceToLocal(item: ApiEvidence): typeof evidenceData[number] {
  return { id: item.id, type: item.type, date: item.date, source: item.source, caseId: item.case_id, related: item.related_entities || [], description: item.description, status: item.validation_status as typeof evidenceData[number]["status"] };
}

function apiTimelineToLocal(item: ApiTimelineEvent): typeof timeline[number] {
  const tone = item.event_type.includes("Transaction") ? "green" : item.event_type.includes("Vehicle") ? "amber" : item.event_type.includes("Location") ? "violet" : item.event_type.includes("Evidence") ? "rose" : "cyan";
  return { id: item.id, date: item.date, time: item.time, type: item.event_type, title: item.title, description: item.description, caseId: item.case_id, entities: item.entities || [], tone };
}

const iconMap: Record<string, typeof LayoutDashboard> = {
  grid: LayoutDashboard,
  folder: FolderOpen,
  network: Network,
  timeline: Activity,
  evidence: ClipboardCheck,
  cross: GitBranch,
  scan: FileSearch,
};

function App() {
  const [started, setStarted] = useState(false);
  const [view, setView] = useState<ViewKey>("overview");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [selectedCase, setSelectedCase] = useState<CaseRecord>(cases[0]);
  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(graphNodes[0]);
  const [search, setSearch] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [validation, setValidation] = useState<Record<string, string>>({});
  const [toast, setToast] = useState("");
  const [analysisText, setAnalysisText] = useState(sampleText);
  const [analysisResults, setAnalysisResults] = useState(() => parseSyntheticText(sampleText));
  const [mobileNav, setMobileNav] = useState(false);
  const [apiStatus, setApiStatus] = useState<"offline" | "connected">("offline");
  const [liveStats, setLiveStats] = useState<DashboardStats | null>(null);
  const [liveCases, setLiveCases] = useState<ApiCase[]>([]);
  const [liveNetwork, setLiveNetwork] = useState<ApiGraph | null>(null);
  const [liveTimeline, setLiveTimeline] = useState<ApiTimelineEvent[]>([]);
  const [liveEvidence, setLiveEvidence] = useState<ApiEvidence[]>([]);
  const [liveCrossCase, setLiveCrossCase] = useState<ApiCrossCase[]>([]);
  const [liveSearchResults, setLiveSearchResults] = useState<ApiSearchResult[]>([]);
  const [backendMessage, setBackendMessage] = useState("");
  const [refreshNonce, setRefreshNonce] = useState(0);

  const showToast = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 2600);
  };

  const navigate = (nextView: ViewKey) => {
    setView(nextView);
    setMobileNav(false);
  };

  useEffect(() => {
    let mounted = true;
    const loadPortfolio = async () => {
      try {
        const health = await getHealth();
        if (health.status !== "ok") throw new Error("API health check failed");
        if (!mounted) return;
        setApiStatus("connected");
        setBackendMessage("");
        try {
          const [stats, caseRows] = await Promise.all([getDashboardStats(), getCases()]);
          if (!mounted) return;
          setLiveStats(stats);
          setLiveCases(caseRows);
          const mappedCases = caseRows.map(apiCaseToRecord);
          if (mappedCases.length) {
            setSelectedCase((current) => mappedCases.find((item) => item.id === current.id) || mappedCases[0]);
          }
        } catch {
          // Keep the shared health-derived connection state; page data may use fallback values.
        }
      } catch {
        if (mounted) { setApiStatus("offline"); setBackendMessage("The hosted FastAPI service did not respond. Retry after the service is available."); }
      }
    };
    loadPortfolio();
    return () => { mounted = false; };
  }, [refreshNonce]);

  useEffect(() => {
    let mounted = true;
    const loadViewData = async () => {
      try {
        if (view === "network" && liveCases.length) setLiveNetwork(await getNetwork(selectedCase.id));
        if (view === "timeline") setLiveTimeline(await getTimeline(selectedCase.id));
        if (view === "evidence") setLiveEvidence(await getEvidence());
        if (view === "cross-case") setLiveCrossCase(await getCrossCase());
      } catch { /* Preserve the shared /api/health connection state. */ }
    };
    if (started) loadViewData();
    return () => { mounted = false; };
  }, [started, view, selectedCase.id, liveCases.length, refreshNonce]);

  useEffect(() => {
    if (search.trim().length < 2) { setLiveSearchResults([]); return; }
    const timer = window.setTimeout(() => { searchRecords(search).then((data) => setLiveSearchResults(data.results)).catch(() => setLiveSearchResults([])); }, 220);
    return () => window.clearTimeout(timer);
  }, [search]);

  const searchResults = useMemo(() => {
    if (search.trim().length < 2) return [];
    if (liveSearchResults.length) return liveSearchResults;
    const query = search.toLowerCase();
    return searchCorpus.filter((item) => `${item.label} ${item.meta} ${item.kind}`.toLowerCase().includes(query)).slice(0, 7);
  }, [search, liveSearchResults]);

  if (!started) {
    return <Landing onLaunch={() => setStarted(true)} />;
  }

  const activeTitle = navItems.find((item) => item.key === view)?.label ?? "Overview";

  // make sure to consider if you need authentication for certain routes
  return (
    <div className="app-shell">
      <aside className={`sidebar ${sidebarOpen ? "sidebar-open" : "sidebar-collapsed"} ${mobileNav ? "mobile-open" : ""}`}>
        <div className="brand-lockup">
          <div className="brand-mark"><Hexagon size={24} strokeWidth={1.5} /><span>SG</span></div>
          {sidebarOpen && <div><p className="brand-name">SENTINEL <span>GRAPH</span></p><p className="brand-subtitle">Investigation intelligence</p></div>}
          <button className="icon-button sidebar-close" onClick={() => setSidebarOpen(false)} aria-label="Collapse navigation"><PanelLeftClose size={17} /></button>
        </div>
        {sidebarOpen && <div className="demo-status"><span className="status-pulse" /> <span>{apiStatus === "connected" ? "Backend Connected" : "Backend Offline"}</span>{apiStatus === "offline" && <span className="status-dot">SYNTHETIC DEMO DATA</span>}{apiStatus === "offline" && <button className="status-retry" title={backendMessage} onClick={() => setRefreshNonce((value) => value + 1)}><RefreshCw size={11} /> Retry</button>}{apiStatus === "offline" && <small className="backend-hint">Start FastAPI on port 8000</small>}</div>}
        <nav className="side-nav" aria-label="Primary navigation">
          {navItems.map((item) => {
            const Icon = iconMap[item.icon];
            return <button key={item.key} className={`nav-item ${view === item.key ? "nav-item-active" : ""}`} onClick={() => navigate(item.key)} title={sidebarOpen ? undefined : item.label}><Icon size={17} strokeWidth={1.8} />{sidebarOpen && <span>{item.label}</span>}{sidebarOpen && item.key === "evidence" && <span className="nav-count">6</span>}</button>;
          })}
        </nav>
        {sidebarOpen && <div className="sidebar-footer">
          <div className="pipeline-label"><span>ANALYSIS PIPELINE</span><span>7 / 8</span></div>
          <div className="pipeline-bar"><span style={{ width: "87%" }} /></div>
          <p>Knowledge graph refreshed <strong>2m ago</strong></p>
          <div className="sidebar-footer-card"><div className="mini-orbit"><Radar size={18} /></div><div><strong>Human review</strong><span>Always required</span></div><ShieldCheck size={15} className="footer-check" /></div>
        </div>}
      </aside>

      <main className={`main-frame ${sidebarOpen ? "with-sidebar" : "wide"}`}>
        <header className="topbar">
          <div className="topbar-left"><button className="icon-button mobile-menu" onClick={() => setMobileNav((prev) => !prev)}><Menu size={19} /></button>{!sidebarOpen && <button className="icon-button expand-sidebar" onClick={() => setSidebarOpen(true)}><PanelLeftOpen size={18} /></button>}<div className="breadcrumb"><span>Workspace</span><ChevronRight size={14} /><strong>{activeTitle}</strong></div></div>
          <div className="topbar-right">
            <div className="search-wrap"><Search size={16} /><input value={search} onFocus={() => setShowSearch(true)} onChange={(event) => { setSearch(event.target.value); setShowSearch(true); }} placeholder="Search people, cases, evidence…" /><kbd>⌘ K</kbd>{showSearch && searchResults.length > 0 && <div className="search-popover">{searchResults.map((result) => <button key={`${result.kind}-${result.id}`} onClick={() => { setSearch(result.label); setShowSearch(false); if (result.kind === "Case") navigate("cases"); else navigate("network"); }}><span className="search-result-icon">{result.kind[0]}</span><span><strong>{result.label}</strong><small>{result.kind} · {result.meta}</small></span><ArrowUpRight size={14} /></button>)}</div>}</div>
            <button className="icon-button notification" onClick={() => showToast("No new critical alerts in the demo workspace")}><Bell size={18} /><span /></button>
            <div className="profile-chip"><div className="avatar">AM</div><div className="profile-copy"><strong>A. Menon</strong><span>Lead investigator</span></div><ChevronDown size={14} /></div>
          </div>
        </header>
        <div className="content-scroll" onClick={() => showSearch && setShowSearch(false)}>
          <div className="content-wrap">
            {view === "overview" && <Overview navigate={navigate} showToast={showToast} setSelectedCase={setSelectedCase} setSelectedNode={setSelectedNode} liveStats={liveStats} />}
            {view === "cases" && <CasesView selectedCase={selectedCase} setSelectedCase={setSelectedCase} navigate={navigate} liveCases={liveCases} />}
            {view === "network" && <NetworkView selectedNode={selectedNode} setSelectedNode={setSelectedNode} showToast={showToast} liveNetwork={liveNetwork} selectedCase={selectedCase} liveCases={liveCases} apiStatus={apiStatus} />}
            {view === "timeline" && <TimelineView selectedCase={selectedCase} liveTimeline={liveTimeline} />}
            {view === "evidence" && <EvidenceView validation={validation} setValidation={setValidation} showToast={showToast} liveEvidence={liveEvidence} onRefresh={() => setRefreshNonce((value) => value + 1)} />}
            {view === "cross-case" && <CrossCaseView navigate={navigate} setSelectedCase={setSelectedCase} liveCrossCase={liveCrossCase} />}
            {view === "analysis" && <AnalysisView text={analysisText} setText={setAnalysisText} results={analysisResults} setResults={setAnalysisResults} showToast={showToast} analyzeBackend={analyzeTextWithBackend} liveCases={liveCases} onSaved={() => setRefreshNonce((value) => value + 1)} />}
          </div>
        </div>
          <footer className="global-disclaimer"><CircleAlert size={13} /> Synthetic demo data · Analytical indicators only · Human validation required</footer>
      </main>
      {toast && <div className="toast"><Check size={16} />{toast}</div>}
    </div>
  );
}

function Landing({ onLaunch }: { onLaunch: () => void }) {
  return <div className="landing-page"><div className="landing-grid" /><div className="landing-noise" /><header className="landing-nav"><div className="brand-lockup"><div className="brand-mark"><Hexagon size={25} strokeWidth={1.5} /><span>SG</span></div><div><p className="brand-name">SENTINEL <span>GRAPH</span></p><p className="brand-subtitle">Investigation intelligence</p></div></div><div className="landing-nav-right"><span className="landing-live"><i /> Local demo ready</span><span className="landing-version">v0.9.6 / 2026</span></div></header><main className="landing-content"><div className="hero-copy"><div className="eyebrow"><span className="eyebrow-line" /> SYNTHETIC INVESTIGATION WORKSPACE</div><h1>From fragmented<br /><em>evidence</em> to connected<br />intelligence.</h1><p className="hero-sub">A visual command layer for turning disconnected records into explainable network insights — built for human investigators, not automated decisions.</p><div className="hero-actions"><button className="primary-button large" onClick={onLaunch}><Sparkles size={17} /> Launch demo investigation <ArrowRight size={17} /></button><button className="ghost-button large" onClick={onLaunch}><PlayIcon /> Explore the workspace</button></div><div className="hero-note"><ShieldCheck size={15} /><span>All entities, locations, records, and relationships are fictional synthetic demo data.</span></div></div><div className="hero-visual"><div className="visual-orbit orbit-one" /><div className="visual-orbit orbit-two" /><div className="hero-center"><div className="hero-center-icon"><Network size={35} strokeWidth={1.4} /></div><span>CONNECTED<br />EVIDENCE</span></div><div className="float-node node-a"><span className="node-symbol person-symbol">P</span><div><strong>Arjun Sharma</strong><small>PERSON · 0.96</small></div></div><div className="float-node node-b"><span className="node-symbol vehicle-symbol">V</span><div><strong>UP16 AB 1234</strong><small>VEHICLE · SHARED</small></div></div><div className="float-node node-c"><span className="node-symbol phone-symbol">⌁</span><div><strong>+91 90000 00001</strong><small>PHONE · 2 CASES</small></div></div><div className="float-node node-d"><span className="node-symbol org-symbol">O</span><div><strong>Asterion Freight</strong><small>ORG · REVIEW</small></div></div></div></main><section className="landing-features"><Feature icon={<Database size={18} />} title="Unified data" copy="People, cases, documents, and signals in one view." /><Feature icon={<BrainCircuit size={18} />} title="Explainable AI" copy="Every insight maps back to evidence and reasoning." /><Feature icon={<GitBranch size={18} />} title="Network analysis" copy="Trace relationships across a living graph." /><Feature icon={<ClipboardCheck size={18} />} title="Human validation" copy="Investigator review is part of the workflow." /></section><footer className="landing-footer"><span>SENTINEL GRAPH · INVESTIGATION INTELLIGENCE</span><span>Designed for a 3–5 minute demonstration flow</span></footer></div>;
}

function PlayIcon() { return <span className="play-icon">▶</span>; }
function Feature({ icon, title, copy }: { icon: React.ReactNode; title: string; copy: string }) { return <div className="landing-feature"><div className="feature-icon">{icon}</div><div><strong>{title}</strong><span>{copy}</span></div></div>; }

function PageHeader({ eyebrow, title, subtitle, action }: { eyebrow: string; title: string; subtitle: string; action?: React.ReactNode }) { return <div className="page-header"><div><div className="section-eyebrow"><span />{eyebrow}</div><h2>{title}</h2><p>{subtitle}</p></div>{action && <div className="page-header-action">{action}</div>}</div>; }
function MiniStat({ icon, label, value, delta, tone = "cyan" }: { icon: React.ReactNode; label: string; value: string; delta: string; tone?: string }) { return <div className="mini-stat"><div className={`mini-stat-icon ${tone}`}>{icon}</div><div className="mini-stat-copy"><span>{label}</span><strong>{value}</strong><small className={delta.startsWith("+") ? "positive" : "neutral"}>{delta}</small></div></div>; }
function StatusPill({ status }: { status: string }) { return <span className={`status-pill ${getStatusTone(status)}`}><i />{status}</span>; }
function Button({ children, variant = "ghost", onClick, icon }: { children: React.ReactNode; variant?: "primary" | "ghost" | "soft"; onClick?: () => void; icon?: React.ReactNode }) { return <button className={`${variant}-button`} onClick={onClick}>{icon}{children}</button>; }

function Overview({ navigate, showToast, setSelectedCase, setSelectedNode, liveStats }: { navigate: (view: ViewKey) => void; showToast: (message: string) => void; setSelectedCase: (item: CaseRecord) => void; setSelectedNode: (node: GraphNode) => void; liveStats: DashboardStats | null }) {
  return <><PageHeader eyebrow="Command center / 01" title="Good morning, Aditi." subtitle="Your synthetic workspace is synced. Here is what deserves attention today." action={<div className="header-actions"><Button onClick={() => showToast("Export queued — synthetic demo snapshot ready shortly")} icon={<Download size={15} />}>Export snapshot</Button><Button variant="primary" onClick={() => navigate("analysis")} icon={<Sparkles size={15} />}>Run analysis</Button></div>} /><div className="overview-hero"><div className="hero-panel-copy"><div className="hero-panel-top"><span className="live-tag"><i /> LIVE DEMO INVESTIGATION</span><span className="hero-case-ref">CASE-2026-001 <ArrowUpRight size={13} /></span></div><h3>North Corridor<br /><em>Logistics Review</em></h3><p>A connected view of synthetic communication, vehicle, location, and transaction records across the North Corridor.</p><div className="hero-panel-meta"><span><UserRound size={14} /> A. Menon</span><span><CalendarDays size={14} /> Updated 2m ago</span><span><Link2 size={14} /> 62 relationships</span></div><button className="hero-panel-button" onClick={() => { setSelectedCase(cases[0]); navigate("cases"); }}>Open case workspace <ArrowRight size={15} /></button></div><div className="hero-panel-graph"><div className="graph-scanline" /><MiniGraph setSelectedNode={setSelectedNode} /></div></div><div className="stat-grid"><MiniStat icon={<FolderOpen size={18} />} label="Active cases" value={String(liveStats?.active_cases ?? 4).padStart(2, "0")} delta={liveStats ? "from SQLite API" : "+1 this week"} tone="cyan" /><MiniStat icon={<Network size={18} />} label="Connected entities" value={String(liveStats?.connected_entities ?? 96)} delta={liveStats ? "from SQLite API" : "+18 since Monday"} tone="violet" /><MiniStat icon={<Link2 size={18} />} label="Detected relationships" value={String(liveStats?.relationships ?? 128)} delta={liveStats ? "from SQLite API" : "+24 this week"} tone="amber" /><MiniStat icon={<ClipboardCheck size={18} />} label="Pending validation" value={String(liveStats?.pending_validation ?? 6).padStart(2, "0")} delta={liveStats ? "from SQLite API" : "2 need attention"} tone="rose" /></div><div className="dashboard-grid"><section className="panel chart-panel"><PanelHeading title="Activity across the workspace" subtitle="Evidence and relationship volume · 10–18 Mar 2026" action={<button className="panel-select" onClick={() => showToast("Showing the most recent 9-day window")}>Last 9 days <ChevronDown size={13} /></button>} /><div className="chart-legend"><span><i className="legend-cyan" /> Connections</span><span><i className="legend-violet" /> Communications</span><span><i className="legend-amber" /> Evidence</span></div><div className="activity-chart"><ResponsiveContainer width="100%" height="100%"><AreaChart data={activityChart} margin={{ top: 8, right: 8, left: -22, bottom: 0 }}><defs><linearGradient id="cyanFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#63d7ff" stopOpacity={0.28} /><stop offset="100%" stopColor="#63d7ff" stopOpacity={0} /></linearGradient><linearGradient id="violetFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#a68bff" stopOpacity={0.2} /><stop offset="100%" stopColor="#a68bff" stopOpacity={0} /></linearGradient></defs><CartesianGrid stroke="rgba(151,176,190,.10)" vertical={false} /><XAxis dataKey="label" stroke="#748896" tickLine={false} axisLine={false} fontSize={10} /><YAxis stroke="#748896" tickLine={false} axisLine={false} fontSize={10} /><Tooltip content={<ChartTooltip />} /><Area type="monotone" dataKey="connections" stroke="#63d7ff" fill="url(#cyanFill)" strokeWidth={2} /><Area type="monotone" dataKey="communications" stroke="#a68bff" fill="url(#violetFill)" strokeWidth={1.7} /></AreaChart></ResponsiveContainer></div></section><section className="panel insight-panel"><PanelHeading title="Explainable insights" subtitle="Generated locally · awaiting human review" action={<button className="text-button" onClick={() => navigate("evidence")}>View all <ArrowRight size={14} /></button>} /> <div className="insight-list">{insightSeeds.map((insight) => <InsightRow key={insight.id} insight={insight} onClick={() => navigate("evidence")} />)}</div></section><section className="panel case-panel"><PanelHeading title="Case pulse" subtitle="Current portfolio status" action={<button className="text-button" onClick={() => navigate("cases")}>All cases <ArrowRight size={14} /></button>} /><div className="case-table"><div className="table-head"><span>Case</span><span>Status</span><span>Signals</span></div>{cases.map((item) => <button className="case-row" key={item.id} onClick={() => { setSelectedCase(item); navigate("cases"); }}><div className="case-cell"><span className="case-code">{item.id}</span><strong>{item.title}</strong></div><StatusPill status={item.status} /><span className="case-signals"><span>{item.entities} entities</span><span>{item.relationships} links</span><ChevronRight size={15} /></span></button>)}</div></section><section className="panel composition-panel"><PanelHeading title="Entity composition" subtitle="96 connected entities in the graph" action={<button className="text-button" onClick={() => navigate("network")}>Open graph <ArrowRight size={14} /></button>} /><div className="composition-body"><div className="donut-wrap"><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={entityBreakdown} dataKey="value" nameKey="label" innerRadius={52} outerRadius={72} paddingAngle={4} stroke="none">{entityBreakdown.map((entry) => <Cell key={entry.label} fill={entry.color} />)}</Pie></PieChart></ResponsiveContainer><div className="donut-center"><strong>96</strong><span>total</span></div></div><div className="composition-legend">{entityBreakdown.map((entry) => <div key={entry.label}><span><i style={{ background: entry.color }} />{entry.label}</span><strong>{entry.value}</strong></div>)}</div></div></section></div></>;
}

function ChartTooltip({ active, payload, label }: { active?: boolean; payload?: { dataKey: string; value: number; color: string }[]; label?: string }) { if (!active || !payload?.length) return null; return <div className="chart-tooltip"><strong>{label}</strong>{payload.map((item) => <span key={item.dataKey} style={{ color: item.color }}>{item.dataKey}: {item.value}</span>)}</div>; }
function PanelHeading({ title, subtitle, action }: { title: string; subtitle: string; action?: React.ReactNode }) { return <div className="panel-heading"><div><h3>{title}</h3><p>{subtitle}</p></div>{action}</div>; }
function InsightRow({ insight, onClick }: { insight: typeof insightSeeds[number]; onClick: () => void }) { return <button className="insight-row" onClick={onClick}><div className="insight-row-top"><span className="insight-tag">{insight.tag}</span><span className="strength">{insight.strength}% <ArrowUpRight size={12} /></span></div><strong>{insight.title}</strong><p>{insight.reason}</p><div className="insight-foot"><span><FileSearch size={12} /> {insight.evidence.join(" · ")}</span><span className="pending-text">{insight.status}</span></div></button>; }

function MiniGraph({ setSelectedNode }: { setSelectedNode: (node: GraphNode) => void }) { return <svg className="mini-graph" viewBox="0 0 470 255" role="img" aria-label="Synthetic network preview"><defs><filter id="glow"><feGaussianBlur stdDeviation="3" result="coloredBlur" /><feMerge><feMergeNode in="coloredBlur" /><feMergeNode in="SourceGraphic" /></feMerge></filter></defs><g className="mini-edges"><line x1="130" y1="119" x2="205" y2="67" /><line x1="205" y1="67" x2="291" y2="112" /><line x1="130" y1="119" x2="220" y2="182" /><line x1="220" y1="182" x2="325" y2="184" /><line x1="291" y1="112" x2="371" y2="78" /><line x1="325" y1="184" x2="381" y2="138" /></g><MiniNode x={130} y={119} color="#63d7ff" label="P" onClick={() => setSelectedNode(graphNodes[0])} /><MiniNode x={205} y={67} color="#b795ff" label="⌁" onClick={() => setSelectedNode(graphNodes[3])} /><MiniNode x={291} y={112} color="#f5bd62" label="V" onClick={() => setSelectedNode(graphNodes[4])} /><MiniNode x={220} y={182} color="#d9e3ea" label="D" onClick={() => setSelectedNode(graphNodes[10])} /><MiniNode x={325} y={184} color="#5de0aa" label="L" onClick={() => setSelectedNode(graphNodes[5])} /><MiniNode x={371} y={78} color="#a4b9c8" label="₹" onClick={() => setSelectedNode(graphNodes[7])} /><circle cx="381" cy="138" r="12" fill="rgba(255,140,168,.14)" stroke="#ff8ca8" /><text x="381" y="142" textAnchor="middle" fill="#ff8ca8" fontSize="11" fontWeight="700">O</text></svg>; }
function MiniNode({ x, y, color, label, onClick }: { x: number; y: number; color: string; label: string; onClick: () => void }) { return <g className="mini-node" onClick={onClick}><circle cx={x} cy={y} r="16" fill={`${color}1f`} stroke={color} /><text x={x} y={y + 4} textAnchor="middle" fill={color} fontSize="11" fontWeight="700">{label}</text></g>; }

function CasesView({ selectedCase, setSelectedCase, navigate, liveCases }: { selectedCase: CaseRecord; setSelectedCase: (item: CaseRecord) => void; navigate: (view: ViewKey) => void; liveCases?: ApiCase[] }) {
  const portfolio = liveCases?.length ? liveCases.map(apiCaseToRecord) : cases;
  const active = portfolio.find((item) => item.id === selectedCase.id) || portfolio[0];
  return <><PageHeader eyebrow="Portfolio / 02" title="Case management" subtitle="Synthetic investigations loaded from the SQLite-backed case portfolio." action={<Button variant="primary" icon={<FolderOpen size={15} />} onClick={() => navigate("evidence")}>Import evidence</Button>} /><div className="case-overview-strip"><div><span className="strip-label">PORTFOLIO HEALTH</span><strong>{liveCases?.length ? "LIVE" : "72"}<span>{liveCases?.length ? " / API" : "/100"}</span></strong><p>Database-backed workspace</p></div><div className="strip-divider" /><div className="case-mini-kpi"><span>Active investigations</span><strong>{portfolio.filter((item) => item.status === "Active").length.toString().padStart(2, "0")}</strong><small>from SQLite</small></div><div className="case-mini-kpi"><span>Awaiting review</span><strong>{portfolio.filter((item) => item.status.includes("Review") || item.status.includes("Validation")).length.toString().padStart(2, "0")}</strong><small>human validation</small></div><div className="case-mini-kpi"><span>Shared entities</span><strong>23</strong><small>cross-case links</small></div><div className="strip-note"><CircleAlert size={15} /><span>Priority is an analytical indicator — not a determination of guilt or criminality.</span></div></div><div className="cases-layout"><section className="panel cases-list-panel"><PanelHeading title="All cases" subtitle="Sorted by most recently updated" action={<span className="panel-select"><Database size={13} /> SQLite records</span>} /><div className="full-case-list">{portfolio.map((item, index) => <button key={item.id} className={`full-case-row ${active.id === item.id ? "selected" : ""}`} onClick={() => setSelectedCase(item)}><div className="case-index">{String(index + 1).padStart(2, "0")}</div><div className="full-case-copy"><div><span className="case-code">{item.id}</span><StatusPill status={item.status} /></div><strong>{item.title}</strong><p>{item.summary}</p><div className="case-row-meta"><span><CalendarDays size={13} /> Updated {item.updated}</span><span><UsersRound size={13} /> {item.entities ?? 0} entities</span><span><Link2 size={13} /> {item.relationships ?? 0} links</span></div></div><ChevronRight size={18} className="case-chevron" /></button>)}</div></section><section className="panel selected-case-panel"><div className="selected-case-banner"><div className="case-rings"><span /><span /><span /><div><FolderOpen size={22} /></div></div><div><span className="case-code">SELECTED INVESTIGATION</span><h3>{active.id}</h3><StatusPill status={active.status} /></div></div><div className="selected-case-body"><span className="section-eyebrow"><span /> CASE OVERVIEW</span><h3>{active.title}</h3><p>{active.summary}</p><div className="case-detail-grid"><div><span>Lead investigator</span><strong>{active.investigator}</strong></div><div><span>Category</span><strong>{active.category}</strong></div><div><span>Created</span><strong>{active.created}</strong></div><div><span>Last updated</span><strong>{active.updated}</strong></div></div><div className="selected-case-actions"><Button variant="primary" onClick={() => navigate("network")} icon={<Network size={15} />}>Open network</Button><Button onClick={() => navigate("timeline")} icon={<History size={15} />}>View timeline</Button></div></div><div className="selected-case-bottom"><span><Target size={14} /> {active.entities ?? 0} connected entities</span><span><Link2 size={14} /> {active.relationships ?? 0} relationships</span><span><ClipboardCheck size={14} /> database evidence</span></div></section></div></>;
}
function NetworkView({ selectedNode, setSelectedNode, showToast, liveNetwork, selectedCase, liveCases, apiStatus }: { selectedNode: GraphNode | null; setSelectedNode: (node: GraphNode | null) => void; showToast: (message: string) => void; liveNetwork: ApiGraph | null; selectedCase: CaseRecord; liveCases: ApiCase[]; apiStatus: "offline" | "connected" }) {
  const localGraph = useMemo(() => liveNetwork ? apiGraphToLocal(liveNetwork) : apiStatus === "connected" ? { nodes: [], edges: [] } : { nodes: graphNodes, edges: graphEdges }, [liveNetwork, apiStatus]);
  const nodes = localGraph.nodes; const edges = localGraph.edges;
  const laidOutNodes = useMemo(() => layoutGraph(nodes, edges), [nodes, edges]);
  const [filter, setFilter] = useState("ALL");
  const [sourceId, setSourceId] = useState(""); const [targetId, setTargetId] = useState("");
  const [pathResult, setPathResult] = useState<ApiPath | null>(null);
  const [zoom, setZoom] = useState(1); const [pan, setPan] = useState({ x: 0, y: 0 });
  const [showRelationshipLabels, setShowRelationshipLabels] = useState(false);
  const [hoveredEdgeId, setHoveredEdgeId] = useState<string | null>(null); const [selectedEdgeId, setSelectedEdgeId] = useState<string | null>(null);
  const [hoveredNodeId, setHoveredNodeId] = useState<string | null>(null); const [focusMode, setFocusMode] = useState(false);
  const dragRef = useRef<{ x: number; y: number; panX: number; panY: number } | null>(null);

  useEffect(() => {
    if (nodes.length && (!sourceId || !nodes.some((node) => node.id === sourceId))) setSourceId(nodes[0].id);
    if (nodes.length > 1 && (!targetId || !nodes.some((node) => node.id === targetId))) setTargetId(nodes[1].id);
    if (selectedNode && !nodes.some((node) => node.id === selectedNode.id)) setSelectedNode(nodes[0] || null);
    setZoom(1); setPan({ x: 0, y: 0 }); setFocusMode(false); setPathResult(null);
  }, [liveNetwork, nodes.length]);

  const visibleNodes = laidOutNodes.filter((node) => filter === "ALL" || node.type === filter);
  const visibleIds = new Set(visibleNodes.map((node) => node.id));
  const visibleEdges = edges.filter((edge) => visibleIds.has(edge.source) && visibleIds.has(edge.target));
  const nodeById = new Map(visibleNodes.map((node) => [node.id, node]));
  const activeNode = selectedNode && nodes.find((node) => node.id === selectedNode.id) ? selectedNode : null;
  const related = activeNode ? nodes.filter((node) => edges.some((edge) => (edge.source === activeNode.id && edge.target === node.id) || (edge.target === activeNode.id && edge.source === node.id))) : [];
  const selectedNeighborhood = new Set([...(activeNode ? [activeNode.id] : []), ...related.map((node) => node.id)]);
  const pathNodeIds = new Set(pathResult?.found ? pathResult.path : []);
  const primaryNodeIds = pathNodeIds.size ? pathNodeIds : new Set([sourceId, targetId].filter(Boolean));
  const primaryEdgeIds = new Set(pathResult?.found ? pathResult.edges.flatMap((pathEdge) => visibleEdges.filter((edge) => (edge.source === pathEdge.source && edge.target === pathEdge.target) || (edge.source === pathEdge.target && edge.target === pathEdge.source)).map((edge) => edge.id)) : []);

  const fitViewport = (ids: Set<string> = new Set(visibleNodes.map((node) => node.id))) => {
    const targets = visibleNodes.filter((node) => ids.has(node.id));
    if (!targets.length) return;
    const minX = Math.min(...targets.map((node) => node.x)); const maxX = Math.max(...targets.map((node) => node.x));
    const minY = Math.min(...targets.map((node) => node.y)); const maxY = Math.max(...targets.map((node) => node.y));
    const width = Math.max(220, maxX - minX + 180); const height = Math.max(180, maxY - minY + 150);
    const nextZoom = Math.min(1.45, Math.max(.72, Math.min(820 / width, 470 / height)));
    setZoom(nextZoom); setPan({ x: nextZoom * (480 - (minX + maxX) / 2), y: nextZoom * (290 - (minY + maxY) / 2) });
  };

  useEffect(() => {
    if (focusMode && primaryNodeIds.size) fitViewport(primaryNodeIds);
  }, [focusMode, pathResult, filter]);

  const findConnection = async () => {
    if (!sourceId || !targetId || sourceId === targetId) return showToast("Choose two different entities");
    try { const result = await getPath(sourceId, targetId, selectedCase.id); setPathResult(result); setFocusMode(result.found); if (!result.found) showToast(result.explanation || "No path found between the selected entities"); }
    catch { showToast("Path finder is unavailable while the backend is offline"); }
  };
  const resetView = () => { setZoom(1); setPan({ x: 0, y: 0 }); setFocusMode(false); setPathResult(null); setSelectedEdgeId(null); };
  const nodeIsDimmed = (node: GraphNode) => focusMode && primaryNodeIds.size > 0 ? !primaryNodeIds.has(node.id) && !selectedNeighborhood.has(node.id) : Boolean(activeNode && !selectedNeighborhood.has(node.id));
  const edgeIsPrimary = (edge: GraphEdge) => primaryEdgeIds.has(edge.id);
  const edgeIsRelated = (edge: GraphEdge) => Boolean(activeNode && (edge.source === activeNode.id || edge.target === activeNode.id));

  return <><PageHeader eyebrow="Graph intelligence / 03" title="Network analysis" subtitle="Trace primary paths, inspect direct connections, and review cross-case links." action={<div className="header-actions"><Button onClick={() => { resetView(); showToast(liveNetwork ? "Graph refreshed from NetworkX" : apiStatus === "connected" && !liveCases.length ? "No saved graph records for the live cases" : "Backend graph unavailable — showing local fallback"); }} icon={<RefreshCw size={15} />}>Recalculate</Button><Button variant="primary" onClick={findConnection} icon={<Crosshair size={15} />}>Find connection</Button></div>} /><div className="network-kpis"><MiniStat icon={<Network size={17} />} label="Total nodes" value={String(liveNetwork?.stats.total_nodes ?? (apiStatus === "connected" ? 0 : 96))} delta={liveNetwork ? "from NetworkX" : "+18 this week"} /><MiniStat icon={<Link2 size={17} />} label="Connections" value={String(liveNetwork?.stats.total_connections ?? (apiStatus === "connected" ? 0 : 128))} delta={liveNetwork ? "from SQLite" : "+24 this week"} tone="violet" /><MiniStat icon={<GitBranch size={17} />} label="Components" value={String(liveNetwork?.stats.connected_components ?? (apiStatus === "connected" ? 0 : 7)).padStart(2, "0")} delta={liveNetwork ? "computed live" : "3 cross-case"} tone="amber" /><MiniStat icon={<Target size={17} />} label="Graph density" value={liveNetwork ? (liveNetwork.stats.total_connections / Math.max(1, liveNetwork.stats.total_nodes)).toFixed(3) : apiStatus === "connected" ? "0.000" : "0.071"} delta="NetworkX" tone="green" /></div><div className="network-layout"><section className="panel graph-panel"><div className="graph-toolbar"><div className="graph-toolbar-left"><span className="toolbar-label">FILTER BY ENTITY</span><div className="filter-chips"><button className={filter === "ALL" ? "active" : ""} onClick={() => setFilter("ALL")}>All <span>{nodes.length}</span></button>{["PERSON", "PHONE", "VEHICLE", "LOCATION", "ORG", "ACCOUNT", "DOCUMENT"].map((type) => <button key={type} className={filter === type ? "active" : ""} onClick={() => setFilter(type)}>{entityTypeStyles[type as keyof typeof entityTypeStyles]?.label || type}<span>{nodes.filter((node) => node.type === type).length}</span></button>)}</div></div><div className="path-finder-controls"><button className={`graph-label-toggle ${showRelationshipLabels ? "active" : ""}`} onClick={() => setShowRelationshipLabels((value) => !value)} aria-pressed={showRelationshipLabels}>Labels {showRelationshipLabels ? "on" : "off"}</button><button className={`graph-label-toggle ${focusMode ? "active" : ""}`} onClick={() => { if (primaryNodeIds.size) { setFocusMode(true); fitViewport(primaryNodeIds); } else showToast("Choose source and target entities first"); }} aria-pressed={focusMode}>Focus path</button><button className="graph-label-toggle" onClick={() => fitViewport()}>Fit graph</button><select aria-label="Path source" value={sourceId} onChange={(event) => setSourceId(event.target.value)}>{nodes.map((node) => <option key={node.id} value={node.id}>{node.label}</option>)}</select><ArrowRight size={13} /><select aria-label="Path target" value={targetId} onChange={(event) => setTargetId(event.target.value)}>{nodes.map((node) => <option key={node.id} value={node.id}>{node.label}</option>)}</select><button className="icon-button" onClick={findConnection} aria-label="Find connection"><Crosshair size={15} /></button><button className="icon-button" onClick={resetView} aria-label="Reset graph view"><History size={15} /></button></div></div><div className="graph-stage"><div className="graph-grid" /><svg viewBox="0 0 960 580" className="network-svg" role="img" aria-label="Interactive synthetic network graph" onPointerDown={(event) => { if (event.target === event.currentTarget) { event.currentTarget.setPointerCapture(event.pointerId); dragRef.current = { x: event.clientX, y: event.clientY, panX: pan.x, panY: pan.y }; } }} onPointerMove={(event) => { if (!dragRef.current) return; setPan({ x: dragRef.current.panX + (event.clientX - dragRef.current.x) / 2, y: dragRef.current.panY + (event.clientY - dragRef.current.y) / 2 }); }} onPointerUp={() => { dragRef.current = null; }} onPointerCancel={() => { dragRef.current = null; }}><defs><filter id="nodeGlow"><feGaussianBlur stdDeviation="4" result="blur" /><feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge></filter><marker id="arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#637b89" /></marker></defs><g transform={`translate(${pan.x + (1 - zoom) * 480} ${pan.y + (1 - zoom) * 290}) scale(${zoom})`}>{visibleEdges.map((edge) => { const source = nodeById.get(edge.source); const target = nodeById.get(edge.target); if (!source || !target) return null; const primary = edgeIsPrimary(edge); const relatedEdge = edgeIsRelated(edge); const crossCase = source.type === "CASE" || target.type === "CASE" || edge.strength === "Emerging"; const edgeFocused = showRelationshipLabels || hoveredEdgeId === edge.id || selectedEdgeId === edge.id || primary; const dimmed = focusMode && primaryEdgeIds.size > 0 && !primary && !relatedEdge; return <g key={edge.id} className={`network-edge ${primary ? "edge-primary" : ""} ${relatedEdge ? "edge-related" : ""} ${crossCase ? "edge-cross-case" : ""} ${edgeFocused ? "edge-focused" : ""} ${dimmed ? "edge-dimmed" : ""}`} onMouseEnter={() => setHoveredEdgeId(edge.id)} onMouseLeave={() => setHoveredEdgeId(null)} onClick={(event) => { event.stopPropagation(); setSelectedEdgeId(edge.id); }}><line className="edge-hit" x1={source.x} y1={source.y} x2={target.x} y2={target.y} /><line x1={source.x} y1={source.y} x2={target.x} y2={target.y} markerEnd="url(#arrow)" />{edgeFocused && <text x={(source.x + target.x) / 2} y={(source.y + target.y) / 2 - 8}>{edge.label}</text>}</g>; })}{visibleNodes.map((node) => { const style = entityTypeStyles[node.type]; if (!style) return null; const active = activeNode?.id === node.id; const dimmed = nodeIsDimmed(node); const labelLines = graphLabelLines(node.label); const connectedCount = edges.filter((edge) => edge.source === node.id || edge.target === node.id).length; const tooltipX = Math.min(770, Math.max(25, node.x + 30)); const tooltipY = Math.max(12, node.y - 72); return <g key={node.id} className={`graph-node ${active ? "node-active" : ""} ${dimmed ? "node-dimmed" : ""}`} onMouseEnter={() => setHoveredNodeId(node.id)} onMouseLeave={() => setHoveredNodeId(null)} onClick={() => { setSelectedEdgeId(null); setSelectedNode(node); }} tabIndex={0}><circle cx={node.x} cy={node.y} r={active ? 29 : 23} fill={style.soft} stroke={style.color} /><circle cx={node.x} cy={node.y} r="5" fill={style.color} filter="url(#nodeGlow)" /><text className="node-icon" x={node.x} y={node.y + 4} textAnchor="middle" fill={style.color}>{style.icon}</text><text className="node-label" x={node.x} y={node.y + 43} textAnchor="middle">{labelLines.map((line, index) => <tspan key={line} x={node.x} dy={index === 0 ? 0 : 12}>{line}</tspan>)}</text><text className="node-type" x={node.x} y={node.y + 67} textAnchor="middle">{style.label.toUpperCase()}</text>{hoveredNodeId === node.id && <g className="node-tooltip" transform={`translate(${tooltipX} ${tooltipY})`}><rect width="164" height="61" rx="5" /><text x="10" y="15" className="tooltip-kicker">ENTITY</text><text x="10" y="29" className="tooltip-value">{node.label}</text><text x="10" y="43" className="tooltip-meta">{style.label.toUpperCase()} · {connectedCount} CONNECTIONS</text><text x="10" y="55" className="tooltip-meta">{node.cases.length} RELATED CASE{node.cases.length === 1 ? "" : "S"}</text></g>}</g>; })}</g></svg><div className="graph-zoom" aria-label="Graph zoom controls"><button onClick={() => setZoom((value) => Math.min(1.7, value + .15))} aria-label="Zoom in">+</button><span /><button onClick={() => setZoom((value) => Math.max(.65, value - .15))} aria-label="Zoom out">−</button><span /><button onClick={() => fitViewport()} aria-label="Fit graph">⌗</button><span /><button onClick={resetView} aria-label="Reset graph view">•</button></div><div className="graph-legend"><span className="legend-heading">ENTITY TYPES</span>{(Object.keys(entityTypeStyles) as GraphNode["type"][]).map((type) => <span key={type}><i style={{ background: entityTypeStyles[type].color }} />{entityTypeStyles[type].label}</span>)}<span className="legend-heading legend-hierarchy">PATH HIERARCHY</span><span><i className="legend-primary" /> Primary path</span><span><i className="legend-muted" /> Direct</span><span><i className="legend-dashed" /> Cross-case</span></div></div>{pathResult && <div className="path-result"><strong>{pathResult.found ? "Shortest path · focused" : "No path found"}</strong><span>{pathResult.found ? pathResult.path.join(" → ") : pathResult.explanation}</span>{pathResult.edges.map((edge) => <small key={`${edge.source}-${edge.target}`}>{edge.relationship_type} · {edge.evidence} · {edge.reason}</small>)}</div>}</section><aside className="panel node-detail-panel"><div className="node-detail-head"><span className="section-eyebrow"><span /> SELECTED ENTITY</span><button className="icon-button" onClick={() => setSelectedNode(null)}><X size={16} /></button></div>{activeNode ? <><div className="selected-node-identity"><div className="large-node-icon" style={{ color: entityTypeStyles[activeNode.type].color, background: entityTypeStyles[activeNode.type].soft }}>{entityTypeStyles[activeNode.type].icon}</div><div><span className="case-code">{entityTypeStyles[activeNode.type].label.toUpperCase()}</span><h3>{activeNode.label}</h3><span className="confidence-line"><span className="confidence-dot" /> Live relationship record</span></div></div><p className="node-description">{activeNode.detail}</p><div className="detail-section"><div className="detail-section-title"><span>ENTITY SIGNALS</span></div><div className="entity-signal-row"><span>Connections</span><strong>{edges.filter((edge) => edge.source === activeNode.id || edge.target === activeNode.id).length}</strong></div><div className="entity-signal-row"><span>Related cases</span><strong>{activeNode.cases.length}</strong></div></div><div className="detail-section"><div className="detail-section-title"><span>RELATED ENTITIES</span><strong>{related.length}</strong></div>{related.slice(0, 6).map((node) => <button className="related-entity" key={node.id} onClick={() => setSelectedNode(node)}><span className="related-icon" style={{ color: entityTypeStyles[node.type].color, background: entityTypeStyles[node.type].soft }}>{entityTypeStyles[node.type].icon}</span><span><strong>{node.label}</strong><small>{entityTypeStyles[node.type].label} · {node.cases.length} case{node.cases.length > 1 ? "s" : ""}</small></span><ChevronRight size={14} /></button>)}</div><div className="detail-section"><div className="detail-section-title"><span>RELATED CASES</span></div><div className="case-membership">{activeNode.cases.map((caseId) => <span key={caseId}><FolderOpen size={12} /> {caseId}</span>)}</div></div><button className="full-width-button" onClick={findConnection}><Crosshair size={15} /> Find path between selected entities</button></> : <div className="empty-detail"><Network size={28} /><p>Select a node in the live graph to inspect its relationships.</p></div>}</aside></div></>;
}

function TimelineView({ selectedCase, liveTimeline }: { selectedCase: CaseRecord; liveTimeline?: ApiTimelineEvent[] }) { const [filter, setFilter] = useState("All events"); const [entity, setEntity] = useState(""); const filters = ["All events", "Communication", "Vehicle sighting", "Transaction", "Location visit", "Evidence", "Case event"]; const source = liveTimeline?.length ? liveTimeline.map(apiTimelineToLocal) : timeline; const filtered = source.filter((event) => (filter === "All events" || event.type === filter) && (!entity || event.entities.some((item) => item.toLowerCase().includes(entity.toLowerCase())))).sort((a, b) => `${a.date} ${a.time}`.localeCompare(`${b.date} ${b.time}`)); return <><PageHeader eyebrow="Temporal intelligence / 04" title="Timeline analysis" subtitle="Chronological events loaded from the SQLite timeline service." action={<div className="header-actions"><span className="panel-select"><Database size={14} /> {liveTimeline?.length ? "LIVE DATABASE" : "LOCAL FALLBACK"}</span><Button variant="primary" icon={<Download size={15} />} onClick={() => { const blob = new Blob([JSON.stringify(filtered, null, 2)], { type: "application/json" }); const url = URL.createObjectURL(blob); const link = document.createElement("a"); link.href = url; link.download = `${selectedCase.id}-timeline.json`; link.click(); URL.revokeObjectURL(url); }}>Export timeline</Button></div>} /><div className="timeline-summary"><div className="timeline-date-range"><span className="case-code">ACTIVE WINDOW</span><strong>10 Mar <em>→</em> 18 Mar</strong><small>{filtered.length} events indexed for {selectedCase.id}</small></div><div className="timeline-progress"><div className="timeline-progress-label"><span>Activity coverage</span><strong>{Math.min(100, filtered.length * 3)}%</strong></div><div className="progress-track"><span style={{ width: `${Math.min(100, filtered.length * 3)}%` }} /></div><div className="timeline-progress-foot"><span>First signal <b>{filtered[0]?.date || "—"}</b></span><span>Last signal <b>{filtered[filtered.length - 1]?.date || "—"}</b></span></div></div><div className="timeline-stat"><Clock3 size={17} /><div><strong>{filtered.length.toString().padStart(2, "0")}</strong><span>chronological records</span></div></div></div><div className="timeline-layout"><section className="panel timeline-panel"><div className="timeline-toolbar"><div className="filter-chips">{filters.map((item) => <button key={item} className={filter === item ? "active" : ""} onClick={() => setFilter(item)}>{item}</button>)}</div><input className="timeline-entity-filter" value={entity} onChange={(event) => setEntity(event.target.value)} placeholder="Filter entity…" /><span className="panel-select"><FolderOpen size={13} /> {selectedCase.id}</span></div><div className="timeline-list">{filtered.map((event, index) => <div className="timeline-event" key={event.id}><div className="timeline-axis"><span className={`timeline-dot ${event.tone}`} /><span className="timeline-line" /></div><div className="timeline-event-date"><strong>{event.date}</strong><span>{event.time}</span></div><div className="timeline-event-card"><div className="event-card-top"><span className={`event-type ${event.tone}`}>{event.type}</span><span className="event-case">{event.caseId}</span></div><h3>{event.title}</h3><p>{event.description}</p><div className="event-entities">{event.entities.map((item) => <span key={item}><Link2 size={12} /> {item}</span>)}</div></div>{index < filtered.length - 1 && <div className="event-gap">chronological</div>}</div>)}</div></section><aside className="panel timeline-side"><PanelHeading title="Activity by type" subtitle="Live event counts" /><div className="timeline-bars"><ResponsiveContainer width="100%" height="100%"><BarChart data={filters.slice(1, 6).map((type) => ({ type, value: source.filter((event) => event.type === type).length }))} layout="vertical" margin={{ left: 8, right: 12, top: 4, bottom: 4 }}><CartesianGrid stroke="rgba(151,176,190,.10)" horizontal={false} /><XAxis type="number" hide /><YAxis type="category" dataKey="type" stroke="#9aadb9" tickLine={false} axisLine={false} fontSize={9} width={92} /><Tooltip content={<ChartTooltip />} /><Bar dataKey="value" fill="#63d7ff" radius={[0, 5, 5, 0]} barSize={9} /></BarChart></ResponsiveContainer></div><div className="timeline-side-note"><Sparkles size={16} /><div><strong>Database-backed sequence</strong><p>Events are synthetic and require investigator interpretation. The ordering is descriptive, not a finding.</p></div></div></aside></div></>; }
function EvidenceView({ validation, setValidation, showToast, liveEvidence, onRefresh }: { validation: Record<string, string>; setValidation: React.Dispatch<React.SetStateAction<Record<string, string>>>; showToast: (message: string) => void; liveEvidence?: ApiEvidence[]; onRefresh?: () => void }) { const [filter, setFilter] = useState("All"); const source = liveEvidence?.length ? liveEvidence.map(apiEvidenceToLocal) : evidenceData; const filtered = source.filter((item) => filter === "All" || (validation[item.id] || item.status) === filter); const update = async (id: string, status: string) => { const note = status === "Add Note" ? window.prompt("Investigator note", "Reviewed synthetic evidence.") || "" : ""; try { await validateEvidence(id, status, note); setValidation((current) => ({ ...current, [id]: status === "Review later" ? "Unreviewed" : status === "Add Note" ? "Unreviewed" : status })); onRefresh?.(); showToast(`${id} persisted as ${status.toLowerCase()}`); } catch { setValidation((current) => ({ ...current, [id]: status })); showToast(`${id} updated locally; backend unavailable`); } }; return <><PageHeader eyebrow="Evidence desk / 05" title="Evidence review" subtitle="Review source-backed signals from the live evidence API before they influence investigation state." action={<div className="header-actions"><Button onClick={() => showToast("Use POST /api/import for TXT, CSV, JSON, or PDF uploads")} icon={<Download size={15} />}>Import instructions</Button><Button variant="primary" onClick={() => onRefresh?.()} icon={<RefreshCw size={15} />}>Refresh evidence</Button></div>} /><div className="evidence-summary"><div className="evidence-summary-copy"><div className="eyebrow"><span className="eyebrow-line" /> HUMAN-IN-THE-LOOP WORKFLOW</div><h3>Nothing is confirmed<br /><em>by the model alone.</em></h3><p>Every extracted entity, relationship, and insight stays in a review queue until an investigator makes the decision.</p></div><div className="evidence-summary-stats"><div><strong>{source.length.toString().padStart(2, "0")}</strong><span>Total evidence</span></div><div><strong>{source.filter((item) => (validation[item.id] || item.status) === "Unreviewed").length.toString().padStart(2, "0")}</strong><span>Unreviewed</span></div><div><strong>{source.filter((item) => (validation[item.id] || item.status) === "Rejected").length.toString().padStart(2, "0")}</strong><span>Rejected</span></div></div><div className="evidence-flow"><span className="flow-step done"><i>1</i> Detected</span><ArrowRight size={14} /><span className="flow-step current"><i>2</i> Review</span><ArrowRight size={14} /><span className="flow-step"><i>3</i> Validate</span></div></div><div className="evidence-toolbar"><div className="filter-chips">{["All", "Unreviewed", "Confirmed", "Rejected"].map((item) => <button className={filter === item ? "active" : ""} onClick={() => setFilter(item)} key={item}>{item}<span>{item === "All" ? source.length : source.filter((e) => (validation[e.id] || e.status) === item).length}</span></button>)}</div><span className="evidence-count">{liveEvidence?.length ? "Live API records" : "Fallback records"} · Showing {filtered.length}</span></div><div className="evidence-grid">{filtered.map((item) => <EvidenceCard key={item.id} item={item} effectiveStatus={validation[item.id] || item.status} update={update} />)}</div></>; }
function CrossCaseView({ navigate, setSelectedCase, liveCrossCase }: { navigate: (view: ViewKey) => void; setSelectedCase: (item: CaseRecord) => void; liveCrossCase?: ApiCrossCase[] }) { const fallback = [{ entity: "UP16 AB 1234", type: "Vehicle", cases: ["CASE-2026-001", "CASE-2026-003"], confidence: "High", why: "Same synthetic vehicle identifier appears in two evidence records four days apart.", evidence: ["EV-118", "EV-221"] }, { entity: "+91 90000 00001", type: "Phone", cases: ["CASE-2026-001", "CASE-2026-002"], confidence: "Moderate", why: "Communication metadata overlaps across two synthetic case windows.", evidence: ["EV-104", "EV-121"] }]; const shared = liveCrossCase?.length ? liveCrossCase.map((item) => ({ entity: item.entity, type: item.type, cases: item.cases, confidence: "Moderate", why: item.explanation, evidence: item.evidence.map((record) => record.id) })) : fallback; const [filter, setFilter] = useState("All"); const visible = filter === "All" ? shared : shared.filter((item) => item.type.toLowerCase().includes(filter.toLowerCase().replace(/s$/, ""))); return <><PageHeader eyebrow="Discovery layer / 06" title="Cross-case discovery" subtitle="Shared synthetic entities calculated from the live database relationship graph." action={<Button variant="primary" icon={<RefreshCw size={15} />} onClick={() => setFilter("All")}>Run discovery</Button>} /><div className="cross-hero"><div className="cross-hero-copy"><div className="eyebrow"><span className="eyebrow-line" /> SHARED ENTITY DETECTION</div><h3>Separate cases.<br /><em>One connected view.</em></h3><p>Sentinel Graph found <strong>{shared.length} shared entities</strong> across the active portfolio. Each link includes supporting synthetic evidence for review.</p></div><div className="case-connection-map"><div className="connection-case left"><span>{shared[0]?.cases[0] || "CASE-A"}</span><small>Case A</small></div><div className="connection-line"><span>shared synthetic entity</span><i /><i /><i /></div><div className="connection-case right"><span>{shared[0]?.cases[1] || "CASE-B"}</span><small>Case B</small></div></div></div><div className="cross-toolbar"><div className="filter-chips">{["All", "People", "Vehicles", "Locations", "Organizations", "Phones", "Accounts"].map((item) => <button key={item} className={filter === item ? "active" : ""} onClick={() => setFilter(item)}>{item}<span>{item === "All" ? shared.length : shared.filter((entry) => entry.type.toLowerCase().includes(item.toLowerCase().replace(/s$/, ""))).length}</span></button>)}</div><span className="panel-select"><Database size={13} /> {liveCrossCase?.length ? "LIVE DATABASE" : "LOCAL FALLBACK"}</span></div><div className="shared-grid">{visible.map((item) => <article className="shared-card" key={`${item.entity}-${item.cases.join("-")}`}><div className="shared-card-top"><div className="shared-entity-icon"><Link2 size={16} /></div><div><span className="case-code">{item.type.toUpperCase()}</span><h3>{item.entity}</h3></div><span className="confidence-pill moderate">{item.confidence}</span></div><p>{item.why}</p><div className="shared-cases"><button onClick={() => { const itemCase = cases.find((entry) => entry.id === item.cases[0]); if (itemCase) setSelectedCase(itemCase); navigate("cases"); }}>{item.cases[0]} <ArrowUpRight size={12} /></button><span>↔</span><button onClick={() => { const itemCase = cases.find((entry) => entry.id === item.cases[1]); if (itemCase) setSelectedCase(itemCase); navigate("cases"); }}>{item.cases[1]} <ArrowUpRight size={12} /></button></div><div className="shared-card-foot"><span><FileSearch size={12} /> {item.evidence.join(" · ") || "Relationship metadata"}</span><button onClick={() => navigate("evidence")}>Review evidence <ArrowRight size={13} /></button></div></article>)}</div><div className="cross-note"><CircleAlert size={15} /><span>Shared entities create a connection for review. They do not prove criminal activity or wrongdoing.</span></div></>; }
function AnalysisView({ text, setText, results, setResults, showToast, analyzeBackend, liveCases, onSaved }: { text: string; setText: (value: string) => void; results: ReturnType<typeof parseSyntheticText>; setResults: (value: ReturnType<typeof parseSyntheticText>) => void; showToast: (message: string) => void; analyzeBackend: (value: string) => Promise<AnalysisResponse>; liveCases: ApiCase[]; onSaved: () => void }) {
  const [analyzed, setAnalyzed] = useState(true);
  const [analysis, setAnalysis] = useState<AnalysisResponse | null>(null);
  const [caseId, setCaseId] = useState("");
  const [newCaseTitle, setNewCaseTitle] = useState("");
  const [saving, setSaving] = useState(false);
  const runAnalysis = async () => {
    setAnalyzed(false);
    try {
      const response = await analyzeBackend(text);
      setAnalysis(response);
      setResults(response.entities.map((item) => ({ type: item.type, value: item.value, confidence: item.confidence })));
      showToast("Backend entity and relationship analysis complete");
    } catch {
      setAnalysis(null);
      setResults(parseSyntheticText(text));
      showToast("Backend unavailable — local extraction used");
    } finally { setAnalyzed(true); }
  };
  const saveApproved = async () => {
    if (!analysis) { showToast("Run analysis before saving suggestions"); return; }
    if (!caseId && !newCaseTitle.trim()) { showToast("Select a case or enter a new case title"); return; }
    setSaving(true);
    try {
      const saved = await saveAnalysis({ case_id: caseId || undefined, case_title: caseId ? undefined : newCaseTitle.trim(), summary: analysis.summary, entities: analysis.entities, relationships: analysis.relationships });
      showToast(`${saved.saved_entities} entities and ${saved.saved_relationships} relationships saved as pending review`);
      onSaved();
    } catch { showToast("Could not save analysis suggestions"); }
    finally { setSaving(false); }
  };
  return <><PageHeader eyebrow="Evidence intelligence / 07" title="Text analysis" subtitle="Analyze pasted investigation text through FastAPI, then approve candidate signals into the relationship graph." action={<div className="header-actions"><Button onClick={() => { setText(sampleText); setResults(parseSyntheticText(sampleText)); setAnalysis(null); }} icon={<RefreshCw size={15} />}>Load sample</Button><Button variant="primary" onClick={runAnalysis} icon={<Sparkles size={15} />}>Analyze text</Button></div>} /><div className="analysis-layout"><section className="panel input-panel"><div className="analysis-panel-top"><PanelHeading title="Input evidence" subtitle="Gemini suggestions with regex fallback" /><span className="local-badge"><i /> HUMAN REVIEW REQUIRED</span></div><textarea value={text} onChange={(event) => setText(event.target.value)} spellCheck={false} /><div className="input-footer"><span><BookOpen size={13} /> TXT, CSV, JSON, PDF supported</span><span>{text.length} characters</span></div><div className="extract-pipeline"><span className="pipeline-node active"><i>1</i> Clean</span><ArrowRight size={13} /><span className="pipeline-node active"><i>2</i> Extract</span><ArrowRight size={13} /><span className="pipeline-node active"><i>3</i> Relate</span><ArrowRight size={13} /><span className="pipeline-node"><i>4</i> Review</span></div></section><section className="panel results-panel"><div className="analysis-panel-top"><PanelHeading title="Extracted signals" subtitle={analyzed ? `${results.length} entities found · ${analysis?.relationships.length || 0} relationships pending review` : "Running analysis…"} /><span className="confidence-avg"><span>AVG. CONFIDENCE</span><strong>{results.length ? (results.reduce((sum, item) => sum + item.confidence, 0) / results.length).toFixed(2) : "—"}</strong></span></div>{!analyzed ? <div className="analysis-loading"><RefreshCw size={22} className="spin" /><span>Analyzing evidence…</span></div> : <div className="entity-result-grid">{results.map((result, index) => <div className="entity-result" key={`${result.type}-${result.value}-${index}`}><span className="result-type">{result.type}</span><strong>{result.value}</strong><div><span className="confidence-meter"><i style={{ width: `${result.confidence * 100}%` }} /></span><small>{result.confidence.toFixed(2)}</small></div></div>)}</div>}</section></div><section className="panel" style={{ marginTop: 16, padding: 16 }}><div className="analysis-panel-top"><PanelHeading title="Review and save" subtitle="Saved records remain pending review until validated in Evidence Review." /><Button variant="primary" onClick={saveApproved}>{saving ? "Saving…" : "Save approved suggestions"}</Button></div><div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}><select value={caseId} onChange={(event) => { setCaseId(event.target.value); setNewCaseTitle(""); }} aria-label="Existing case"><option value="">Create new case…</option>{liveCases.map((item) => <option key={item.id} value={item.id}>{item.id} · {item.title}</option>)}</select>{!caseId && <input value={newCaseTitle} onChange={(event) => setNewCaseTitle(event.target.value)} placeholder="New case title" aria-label="New case title" />}</div></section><div className="analysis-footnote"><CircleAlert size={14} /><span>Candidate entities and relationships are never confirmed automatically. Saving records them as Pending Review and refreshes the Network Graph.</span></div></>;
}

function EvidenceCard({ item, effectiveStatus, update }: { item: typeof evidenceData[number]; effectiveStatus: string; update: (id: string, status: string) => void }) { return <article className="evidence-card"><div className="evidence-card-head"><div className={`evidence-type-icon ${item.type.toLowerCase().replace(" ", "-")}`}><FileSearch size={17} /></div><div><span className="case-code">{item.id} · {item.type.toUpperCase()}</span><strong>{item.date}</strong></div><StatusPill status={effectiveStatus} /></div><p>{item.description}</p><div className="evidence-source"><span><Database size={12} /> {item.source}</span><span><FolderOpen size={12} /> {item.caseId}</span></div><div className="evidence-related">{item.related.map((entity) => <span key={entity}>{entity}</span>)}</div><div className="evidence-actions">{effectiveStatus === "Unreviewed" || effectiveStatus === "Pending Validation" ? <><button className="confirm-action" onClick={() => update(item.id, "Confirmed")}><Check size={14} /> Confirm</button><button className="reject-action" onClick={() => update(item.id, "Rejected")}><X size={14} /> Reject</button><button className="review-action" onClick={() => update(item.id, "Add Note")}><MessageSquareText size={14} /> Add note</button></> : <button className="audit-action" onClick={() => update(item.id, effectiveStatus === "Confirmed" ? "Review later" : "Unreviewed")}><History size={14} /> Re-open review</button>}</div></article>; }

export default App;
