export type ViewKey = "overview" | "cases" | "network" | "timeline" | "evidence" | "cross-case" | "analysis";

export type CaseRecord = {
  id: string;
  title: string;
  category: string;
  status: "Active" | "Under Review" | "Pending Validation" | "Closed";
  created: string;
  updated: string;
  entities: number;
  relationships: number;
  investigator: string;
  summary: string;
};

export type GraphNode = {
  id: string;
  label: string;
  type: "PERSON" | "PHONE" | "VEHICLE" | "LOCATION" | "ORG" | "ACCOUNT" | "CASE" | "DOCUMENT";
  x: number;
  y: number;
  cases: string[];
  detail: string;
};

export type GraphEdge = {
  id: string;
  source: string;
  target: string;
  label: string;
  evidence: string;
  strength: "Strong" | "Moderate" | "Emerging";
};

export type EvidenceRecord = {
  id: string;
  type: string;
  date: string;
  source: string;
  caseId: string;
  related: string[];
  description: string;
  status: "Unreviewed" | "Confirmed" | "Rejected" | "Pending Validation" | "Review later";
};

export type TimelineEvent = {
  id: string;
  date: string;
  time: string;
  type: string;
  title: string;
  description: string;
  caseId: string;
  entities: string[];
  tone: "cyan" | "amber" | "violet" | "rose" | "green";
};

export const cases: CaseRecord[] = [
  {
    id: "CASE-2026-001",
    title: "North Corridor Logistics Review",
    category: "Organized logistics",
    status: "Active",
    created: "04 Mar 2026",
    updated: "18 Mar 2026",
    entities: 34,
    relationships: 62,
    investigator: "A. Menon",
    summary: "Synthetic review of a transport and financial activity pattern across the North Corridor.",
  },
  {
    id: "CASE-2026-002",
    title: "Harbor Signal Pattern",
    category: "Communications",
    status: "Under Review",
    created: "09 Mar 2026",
    updated: "17 Mar 2026",
    entities: 21,
    relationships: 38,
    investigator: "R. Iyer",
    summary: "Cross-reference of communication metadata and recurring location visits in a synthetic harbor zone.",
  },
  {
    id: "CASE-2026-003",
    title: "Civic Procurement Anomaly",
    category: "Financial review",
    status: "Pending Validation",
    created: "12 Mar 2026",
    updated: "16 Mar 2026",
    entities: 18,
    relationships: 29,
    investigator: "S. Rao",
    summary: "Synthetic transaction cluster with shared organizations and vehicle sightings.",
  },
  {
    id: "CASE-2026-004",
    title: "East Ring Movement Study",
    category: "Vehicle intelligence",
    status: "Closed",
    created: "18 Feb 2026",
    updated: "11 Mar 2026",
    entities: 16,
    relationships: 24,
    investigator: "N. Khanna",
    summary: "Closed synthetic case used as a historical comparison set for network analysis.",
  },
];

export const graphNodes: GraphNode[] = [
  { id: "arjun", label: "Arjun Sharma", type: "PERSON", x: 245, y: 235, cases: ["CASE-2026-001", "CASE-2026-003"], detail: "Primary synthetic subject in the demo narrative." },
  { id: "ravi", label: "Ravi Verma", type: "PERSON", x: 475, y: 128, cases: ["CASE-2026-001", "CASE-2026-002"], detail: "Contact appearing in synthetic communication metadata." },
  { id: "meera", label: "Meera Nair", type: "PERSON", x: 520, y: 345, cases: ["CASE-2026-002", "CASE-2026-003"], detail: "Synthetic person linked through an organization record." },
  { id: "phone", label: "+91 90000 00001", type: "PHONE", x: 345, y: 128, cases: ["CASE-2026-001", "CASE-2026-002"], detail: "Synthetic communication endpoint. Not a real phone number." },
  { id: "vehicle", label: "UP16 AB 1234", type: "VEHICLE", x: 370, y: 345, cases: ["CASE-2026-001", "CASE-2026-003"], detail: "Synthetic vehicle record shared across two demo cases." },
  { id: "sector", label: "Sector X Transit Yard", type: "LOCATION", x: 620, y: 210, cases: ["CASE-2026-001", "CASE-2026-004"], detail: "Synthetic location label used for demonstration only." },
  { id: "org", label: "Asterion Freight Co.", type: "ORG", x: 720, y: 350, cases: ["CASE-2026-001", "CASE-2026-003"], detail: "Fictional organization used to show shared entity discovery." },
  { id: "account", label: "ACC-1001", type: "ACCOUNT", x: 730, y: 120, cases: ["CASE-2026-001", "CASE-2026-003"], detail: "Synthetic account identifier connected to a demo transaction." },
  { id: "case1", label: "CASE-2026-001", type: "CASE", x: 125, y: 360, cases: ["CASE-2026-001"], detail: "North Corridor Logistics Review." },
  { id: "case3", label: "CASE-2026-003", type: "CASE", x: 835, y: 255, cases: ["CASE-2026-003"], detail: "Civic Procurement Anomaly." },
  { id: "doc", label: "DOC-1042", type: "DOCUMENT", x: 135, y: 120, cases: ["CASE-2026-001"], detail: "Synthetic field note with extracted entities." },
];

export const graphEdges: GraphEdge[] = [
  { id: "e1", source: "arjun", target: "phone", label: "USES", evidence: "EV-104", strength: "Strong" },
  { id: "e2", source: "ravi", target: "phone", label: "CALLED", evidence: "EV-104", strength: "Moderate" },
  { id: "e3", source: "arjun", target: "vehicle", label: "ASSOCIATED_WITH", evidence: "EV-118", strength: "Strong" },
  { id: "e4", source: "vehicle", target: "sector", label: "SEEN_AT", evidence: "EV-118", strength: "Strong" },
  { id: "e5", source: "sector", target: "ravi", label: "VISITED", evidence: "EV-121", strength: "Emerging" },
  { id: "e6", source: "ravi", target: "org", label: "ASSOCIATED_WITH", evidence: "EV-125", strength: "Moderate" },
  { id: "e7", source: "org", target: "account", label: "OWNS", evidence: "EV-132", strength: "Moderate" },
  { id: "e8", source: "account", target: "arjun", label: "TRANSFERRED_TO", evidence: "EV-132", strength: "Moderate" },
  { id: "e9", source: "arjun", target: "case1", label: "MENTIONED_IN", evidence: "DOC-1042", strength: "Strong" },
  { id: "e10", source: "vehicle", target: "case3", label: "RELATED_TO", evidence: "EV-221", strength: "Moderate" },
  { id: "e11", source: "org", target: "case3", label: "ASSOCIATED_WITH", evidence: "EV-226", strength: "Moderate" },
  { id: "e12", source: "meera", target: "org", label: "WORKS_WITH", evidence: "EV-230", strength: "Emerging" },
  { id: "e13", source: "meera", target: "phone", label: "CALLED", evidence: "EV-231", strength: "Emerging" },
  { id: "e14", source: "doc", target: "arjun", label: "MENTIONS", evidence: "DOC-1042", strength: "Strong" },
  { id: "e15", source: "doc", target: "vehicle", label: "MENTIONS", evidence: "DOC-1042", strength: "Strong" },
];

export const evidence: EvidenceRecord[] = [
  { id: "EV-104", type: "Communication", date: "10 Mar 2026", source: "Synthetic call detail record", caseId: "CASE-2026-001", related: ["Arjun Sharma", "Ravi Verma", "+91 90000 00001"], description: "Two communication events share the same synthetic endpoint within a 36-hour window.", status: "Confirmed" },
  { id: "EV-118", type: "Vehicle Record", date: "12 Mar 2026", source: "Synthetic ANPR metadata", caseId: "CASE-2026-001", related: ["UP16 AB 1234", "Sector X Transit Yard"], description: "Vehicle sighting recorded near Sector X Transit Yard at 21:14.", status: "Unreviewed" },
  { id: "EV-121", type: "Location Record", date: "13 Mar 2026", source: "Synthetic access log", caseId: "CASE-2026-002", related: ["Ravi Verma", "Sector X Transit Yard"], description: "A synthetic location visit overlaps with another case window.", status: "Unreviewed" },
  { id: "EV-132", type: "Transaction", date: "14 Mar 2026", source: "Synthetic ledger extract", caseId: "CASE-2026-001", related: ["ACC-1001", "Asterion Freight Co."], description: "Demo transfer of ₹85,000 between two synthetic account references.", status: "Pending Validation" },
  { id: "EV-201", type: "Court Record", date: "15 Mar 2026", source: "Synthetic docket entry", caseId: "CASE-2026-003", related: ["CASE-2026-003"], description: "Reference record included to demonstrate heterogeneous evidence.", status: "Confirmed" },
  { id: "EV-221", type: "Vehicle Record", date: "16 Mar 2026", source: "Synthetic ANPR metadata", caseId: "CASE-2026-003", related: ["UP16 AB 1234", "CASE-2026-003"], description: "The same synthetic vehicle identifier appears in a second case.", status: "Unreviewed" },
  { id: "EV-226", type: "Document", date: "16 Mar 2026", source: "Synthetic invoice packet", caseId: "CASE-2026-003", related: ["Asterion Freight Co.", "CASE-2026-003"], description: "Fictional organization name extracted from a synthetic invoice packet.", status: "Unreviewed" },
  { id: "EV-230", type: "Social Media Record", date: "17 Mar 2026", source: "Synthetic public-post metadata", caseId: "CASE-2026-002", related: ["Meera Nair", "Asterion Freight Co."], description: "Synthetic post metadata suggests an association requiring human review.", status: "Rejected" },
];

export const timeline: TimelineEvent[] = [
  { id: "t1", date: "10 Mar", time: "09:18", type: "Communication", title: "Phone contact detected", description: "Synthetic call metadata links Arjun Sharma and Ravi Verma through +91 90000 00001.", caseId: "CASE-2026-001", entities: ["Arjun Sharma", "Ravi Verma"], tone: "cyan" },
  { id: "t2", date: "12 Mar", time: "21:14", type: "Vehicle sighting", title: "Vehicle seen at Sector X", description: "UP16 AB 1234 appears in synthetic ANPR metadata near the transit yard.", caseId: "CASE-2026-001", entities: ["UP16 AB 1234", "Sector X Transit Yard"], tone: "amber" },
  { id: "t3", date: "13 Mar", time: "18:42", type: "Location visit", title: "Location overlap surfaced", description: "A synthetic access log creates a cross-case overlap for Sector X Transit Yard.", caseId: "CASE-2026-002", entities: ["Ravi Verma", "Sector X Transit Yard"], tone: "violet" },
  { id: "t4", date: "14 Mar", time: "11:05", type: "Transaction", title: "₹85,000 transfer recorded", description: "Synthetic ledger extract connects ACC-1001 and Asterion Freight Co.", caseId: "CASE-2026-001", entities: ["ACC-1001", "Asterion Freight Co."], tone: "green" },
  { id: "t5", date: "15 Mar", time: "16:20", type: "Evidence", title: "Court record indexed", description: "A heterogeneous synthetic record was added to CASE-2026-003 for comparison.", caseId: "CASE-2026-003", entities: ["CASE-2026-003"], tone: "rose" },
  { id: "t6", date: "16 Mar", time: "08:10", type: "Cross-case link", title: "Shared vehicle discovered", description: "UP16 AB 1234 is present in CASE-2026-001 and CASE-2026-003.", caseId: "CASE-2026-003", entities: ["UP16 AB 1234", "CASE-2026-001"], tone: "amber" },
  { id: "t7", date: "17 Mar", time: "13:33", type: "Analysis", title: "Insight queued for validation", description: "The system generated an explainable insight with three supporting evidence references.", caseId: "CASE-2026-001", entities: ["Arjun Sharma", "UP16 AB 1234"], tone: "cyan" },
  { id: "t8", date: "18 Mar", time: "10:02", type: "Investigator review", title: "Review note added", description: "A. Menon requested validation of the vehicle cross-case relationship.", caseId: "CASE-2026-001", entities: ["UP16 AB 1234"], tone: "violet" },
];

export const insightSeeds = [
  { id: "ins-1", tag: "CROSS-CASE", title: "UP16 AB 1234 appears across two synthetic cases", reason: "The same vehicle record is present in CASE-2026-001 and CASE-2026-003 within a four-day window.", evidence: ["EV-118", "EV-221"], related: ["Arjun Sharma", "CASE-2026-001", "CASE-2026-003"], strength: 86, status: "Pending investigator validation" },
  { id: "ins-2", tag: "NETWORK", title: "Arjun Sharma sits at a high-connectivity junction", reason: "The entity is connected to a phone, vehicle, account, document, and case record in the current graph slice.", evidence: ["DOC-1042", "EV-132"], related: ["Arjun Sharma", "ACC-1001", "UP16 AB 1234"], strength: 72, status: "Pending investigator validation" },
  { id: "ins-3", tag: "TEMPORAL", title: "Recent activity clusters across 8 days", reason: "Communication, location, vehicle, and transaction events occur in close sequence during the demo window.", evidence: ["EV-104", "EV-118", "EV-132"], related: ["CASE-2026-001", "CASE-2026-002"], strength: 64, status: "Pending investigator validation" },
];

export const entityTypeStyles: Record<GraphNode["type"], { label: string; color: string; soft: string; icon: string }> = {
  PERSON: { label: "Person", color: "#63d7ff", soft: "rgba(99,215,255,.14)", icon: "P" },
  PHONE: { label: "Phone", color: "#b795ff", soft: "rgba(183,149,255,.14)", icon: "⌁" },
  VEHICLE: { label: "Vehicle", color: "#f5bd62", soft: "rgba(245,189,98,.14)", icon: "V" },
  LOCATION: { label: "Location", color: "#5de0aa", soft: "rgba(93,224,170,.14)", icon: "L" },
  ORG: { label: "Organization", color: "#ff8ca8", soft: "rgba(255,140,168,.14)", icon: "O" },
  ACCOUNT: { label: "Account", color: "#a4b9c8", soft: "rgba(164,185,200,.14)", icon: "₹" },
  CASE: { label: "Case", color: "#ff7a93", soft: "rgba(255,122,147,.14)", icon: "C" },
  DOCUMENT: { label: "Document", color: "#d9e3ea", soft: "rgba(217,227,234,.12)", icon: "D" },
};

export const activityChart = [
  { label: "10 Mar", communications: 6, evidence: 2, connections: 4 },
  { label: "11 Mar", communications: 9, evidence: 3, connections: 7 },
  { label: "12 Mar", communications: 5, evidence: 6, connections: 11 },
  { label: "13 Mar", communications: 12, evidence: 4, connections: 9 },
  { label: "14 Mar", communications: 8, evidence: 8, connections: 14 },
  { label: "15 Mar", communications: 13, evidence: 5, connections: 16 },
  { label: "16 Mar", communications: 10, evidence: 9, connections: 19 },
  { label: "17 Mar", communications: 15, evidence: 6, connections: 22 },
  { label: "18 Mar", communications: 11, evidence: 11, connections: 24 },
];

export const entityBreakdown = [
  { label: "People", value: 20, color: "#63d7ff" },
  { label: "Vehicles", value: 10, color: "#f5bd62" },
  { label: "Locations", value: 15, color: "#5de0aa" },
  { label: "Organizations", value: 10, color: "#ff8ca8" },
  { label: "Other", value: 41, color: "#8ea5b5" },
];

export const searchCorpus = [
  ...graphNodes.map((node) => ({ kind: entityTypeStyles[node.type].label, label: node.label, meta: node.cases.join(" · "), id: node.id })),
  ...cases.map((item) => ({ kind: "Case", label: item.id, meta: item.title, id: item.id })),
  ...evidence.map((item) => ({ kind: "Evidence", label: item.id, meta: `${item.type} · ${item.caseId}`, id: item.id })),
];

export const sampleText = `On 12 March 2026, Person Arjun Sharma contacted Ravi Verma using phone 9000000001.\nThe vehicle UP16AB1234 was seen near Sector X Transit Yard.\nA transaction of ₹85,000 was transferred to Account ACC-1001.\nAsterion Freight Co. was mentioned in document DOC-1042 for CASE-2026-001.`;

export function findNode(id: string) {
  return graphNodes.find((node) => node.id === id);
}

export function connectedNodes(nodeId: string) {
  const ids = graphEdges.flatMap((edge) => edge.source === nodeId ? [edge.target] : edge.target === nodeId ? [edge.source] : []);
  return graphNodes.filter((node) => ids.includes(node.id));
}

export function getStatusTone(status: string) {
  if (status === "Confirmed" || status === "Active") return "green";
  if (status === "Rejected" || status === "Closed") return "red";
  return "amber";
}

export function parseSyntheticText(text: string) {
  const patterns = [
    { type: "PERSON", regex: /\b(?:Person\s+)?([A-Z][a-z]+\s[A-Z][a-z]+)\b/g },
    { type: "PHONE", regex: /(?:phone\s*)?(\+?91[-\s]?\d{10}|\d{10})\b/gi },
    { type: "VEHICLE", regex: /\b[A-Z]{2}\d{2}[A-Z]{2}\d{4}\b/gi },
    { type: "LOCATION", regex: /\b(?:Sector\s+[A-Z]|[A-Z][a-z]+\s(?:Transit Yard|Nagar|District))\b/g },
    { type: "DATE", regex: /\b\d{1,2}\s(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s\d{4}\b/gi },
    { type: "MONEY", regex: /₹\s?[\d,]+|\b(?:INR|Rs\.?)[\s\d,]+/gi },
    { type: "ACCOUNT", regex: /\bACC[-\s]?\d{4}\b/gi },
    { type: "ORGANIZATION", regex: /\b[A-Z][a-z]+\s(?:Freight|Logistics|Industries|Co\.)\b/g },
    { type: "CASE ID", regex: /\bCASE-\d{4}-\d{3}\b/gi },
    { type: "DOCUMENT", regex: /\bDOC-\d{4}\b/gi },
  ];
  const output: { type: string; value: string; confidence: number }[] = [];
  patterns.forEach(({ type, regex }) => {
    const seen = new Set<string>();
    const matches = text.match(regex) || [];
    matches.forEach((match) => {
      const value = (match[1] || match[0]).trim().replace(/\.$/, "");
      const key = value.toLowerCase();
      if (!seen.has(key) && value.length > 2) {
        seen.add(key);
        output.push({ type, value, confidence: type === "PERSON" || type === "VEHICLE" ? 0.96 : 0.91 });
      }
    });
  });
  return output;
}

export const navItems: { key: ViewKey; label: string; icon: string }[] = [
  { key: "overview", label: "Overview", icon: "grid" },
  { key: "cases", label: "Cases", icon: "folder" },
  { key: "network", label: "Network graph", icon: "network" },
  { key: "timeline", label: "Timeline", icon: "timeline" },
  { key: "evidence", label: "Evidence review", icon: "evidence" },
  { key: "cross-case", label: "Cross-case discovery", icon: "cross" },
  { key: "analysis", label: "Text analysis", icon: "scan" },
];
