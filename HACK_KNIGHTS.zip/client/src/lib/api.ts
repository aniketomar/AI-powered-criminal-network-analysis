export type DashboardStats = { active_cases: number; connected_entities: number; relationships: number; cross_case_links: number; pending_validation: number; evidence: number; synthetic_demo: boolean };
export type ApiCase = { id: string; title: string; category: string; status: string; created: string; updated: string; investigator: string; summary: string; entities?: number; relationships?: number };
export type ApiEvidence = { id: string; type: string; date: string; source: string; description: string; case_id: string; related_entities: string[]; validation_status: string };
export type ApiTimelineEvent = { id: string; date: string; time: string; event_type: string; title: string; description: string; case_id: string; entities: string[] };
export type ApiGraph = { nodes: Array<{ id: string; label: string; type: string; cases: string[]; centrality?: number }>; edges: Array<{ id: string; source: string; target: string; label: string; evidence: string; confidence: number; validation_status: string }>; stats: { total_nodes: number; total_connections: number; connected_components: number; most_connected: Array<{ id: string; degree: number }> } };
export type ApiSearchResult = { kind: string; label: string; id: string; meta: string };
export type ApiCrossCase = { entity_id: string; entity: string; type: string; cases: string[]; explanation: string; evidence: ApiEvidence[] };
export type ApiPath = { found: boolean; path: string[]; edges: Array<{ source: string; target: string; relationship_type: string; evidence: string; confidence: number; validation_status: string; reason: string }>; explanation: string };
export type AnalysisEntity = { type: string; value: string; confidence: number };
export type AnalysisRelationship = { source: string; target: string; relationship_type: string; evidence_reference?: string; confidence: number; validation_status?: string };
export type AnalysisResponse = { summary: string; analysis_source: string; entities: AnalysisEntity[]; relationships: AnalysisRelationship[]; evidence: unknown[] };
export type SaveAnalysisResponse = { ok: boolean; case_id: string; evidence_id: string; saved_entities: number; saved_relationships: number; skipped_relationships: number; validation_status: string };

// Production is same-origin: the hosted Node server proxies `/api/*` to FastAPI.
// A separate API origin can be supplied at build time with VITE_API_BASE_URL.
const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || "").replace(/\/$/, "");

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, { ...init, headers: { "Content-Type": "application/json", ...(init?.headers || {}) } });
  if (!response.ok) throw new Error(`Sentinel API ${response.status}`);
  return response.json() as Promise<T>;
}

export const getHealth = () => request<{ status: string; synthetic_demo: boolean }>("/api/health");
export const getDashboardStats = () => request<DashboardStats>("/api/dashboard/stats");
export const getCases = () => request<ApiCase[]>("/api/cases");
export const getCase = (caseId: string) => request<ApiCase & { evidence: ApiEvidence[]; network: ApiGraph }>(`/api/cases/${encodeURIComponent(caseId)}`);
export const getEntity = (entityId: string) => request<{ id: string; label: string; type: string; cases: string[]; relationships: unknown[]; evidence: ApiEvidence[]; related_cases: string[] }>(`/api/entities/${encodeURIComponent(entityId)}`);
export const getEvidence = (caseId?: string, status?: string) => request<ApiEvidence[]>(`/api/evidence?${new URLSearchParams({ ...(caseId ? { case_id: caseId } : {}), ...(status && status !== "All" ? { status } : {}) })}`);
export const getNetwork = (caseId: string) => request<ApiGraph>(`/api/network/${encodeURIComponent(caseId)}`);
export const getTimeline = (caseId: string, params?: { eventType?: string; entity?: string; startDate?: string; endDate?: string }) => request<ApiTimelineEvent[]>(`/api/timeline/${encodeURIComponent(caseId)}?${new URLSearchParams({ ...(params?.eventType && params.eventType !== "All events" ? { event_type: params.eventType } : {}), ...(params?.entity ? { entity: params.entity } : {}), ...(params?.startDate ? { start_date: params.startDate } : {}), ...(params?.endDate ? { end_date: params.endDate } : {}) })}`);
export const getCrossCase = () => request<ApiCrossCase[]>("/api/cross-case");
export const searchRecords = (query: string) => request<{ query: string; results: ApiSearchResult[] }>(`/api/search?q=${encodeURIComponent(query)}`);
export const getPath = (source: string, target: string, caseId?: string) => request<ApiPath>(`/api/path?${new URLSearchParams({ source, target, ...(caseId ? { case_id: caseId } : {}) })}`);
export const analyzeTextWithBackend = (text: string) => request<AnalysisResponse>("/api/analyze-text", { method: "POST", body: JSON.stringify({ text }) });
export const saveAnalysis = (payload: { case_id?: string; case_title?: string; summary: string; entities: AnalysisEntity[]; relationships: AnalysisRelationship[] }) => request<SaveAnalysisResponse>("/api/analyze-text/save", { method: "POST", body: JSON.stringify(payload) });
export const validateEvidence = (targetId: string, action: string, note = "") => request<{ ok: boolean; target_id: string; action: string }>("/api/validate", { method: "POST", body: JSON.stringify({ target_id: targetId, target_type: "evidence", action, investigator: "Demo Investigator", note }) });
