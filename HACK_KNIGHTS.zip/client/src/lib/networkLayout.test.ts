import { describe, expect, it } from "vitest";
import { entityTypeStyles, graphEdges, graphNodes } from "./demoData";
import { graphLabelLines, layoutGraph } from "./networkLayout";

describe("network visualization layout", () => {
  it("preserves every graph node and keeps positions inside the SVG viewport", () => {
    const laidOut = layoutGraph(graphNodes, graphEdges);

    expect(laidOut).toHaveLength(graphNodes.length);
    expect(new Set(laidOut.map((node) => node.id))).toEqual(new Set(graphNodes.map((node) => node.id)));
    expect(laidOut.every((node) => node.x >= 72 && node.x <= 888 && node.y >= 68 && node.y <= 488)).toBe(true);
  });

  it("is deterministic and does not alter edge data", () => {
    const edgeSnapshot = graphEdges.map(({ id, source, target, label }) => ({ id, source, target, label }));
    const first = layoutGraph(graphNodes, graphEdges);
    const second = layoutGraph(graphNodes, graphEdges);

    expect(first.map(({ id, x, y }) => ({ id, x, y }))).toEqual(second.map(({ id, x, y }) => ({ id, x, y })));
    expect(graphEdges).toHaveLength(edgeSnapshot.length);
    expect(graphEdges.map(({ id, source, target, label }) => ({ id, source, target, label }))).toEqual(edgeSnapshot);
  });

  it("wraps long labels while retaining the complete entity name", () => {
    const lines = graphLabelLines("Asterion Freight Co.");
    expect(lines).toHaveLength(2);
    expect(lines.join(" ")).toBe("Asterion Freight Co.");
    expect(graphLabelLines("ACC-1001")).toEqual(["ACC-1001"]);
  });

  it("keeps a semantic color and icon for every graph entity type", () => {
    expect(Object.keys(entityTypeStyles)).toEqual([
      "PERSON",
      "PHONE",
      "VEHICLE",
      "LOCATION",
      "ORG",
      "ACCOUNT",
      "CASE",
      "DOCUMENT",
    ]);
    Object.values(entityTypeStyles).forEach((style) => {
      expect(style.color).toMatch(/^#/);
      expect(style.icon.length).toBeGreaterThan(0);
      expect(style.soft).toContain("rgba");
    });
  });
});
