import type { GraphEdge, GraphNode } from "./demoData";

const ANCHORS: Array<[number, number]> = [
  [130, 120], [350, 105], [575, 120], [805, 118],
  [160, 300], [385, 285], [610, 305], [820, 290],
  [270, 465], [525, 455], [770, 455],
];

/**
 * A bounded, deterministic force-directed relaxation. It runs once per graph
 * payload and deliberately keeps stable anchors so labels stay readable while
 * edges still influence nearby node spacing.
 */
export function layoutGraph(nodes: GraphNode[], edges: GraphEdge[]): GraphNode[] {
  if (nodes.length < 2) return nodes;
  const positions = nodes.map((node, index) => {
    const [x, y] = ANCHORS[index % ANCHORS.length];
    return { node, x, y, anchorX: x, anchorY: y };
  });
  const indexById = new Map(nodes.map((node, index) => [node.id, index]));
  const links = edges.flatMap((edge) => {
    const source = indexById.get(edge.source); const target = indexById.get(edge.target);
    return source === undefined || target === undefined ? [] : [{ source, target }];
  });

  for (let iteration = 0; iteration < 150; iteration += 1) {
    const forces = positions.map(() => ({ x: 0, y: 0 }));
    for (let i = 0; i < positions.length; i += 1) {
      for (let j = i + 1; j < positions.length; j += 1) {
        const dx = positions[i].x - positions[j].x; const dy = positions[i].y - positions[j].y;
        const distance = Math.max(30, Math.hypot(dx, dy)); const strength = 11000 / (distance * distance);
        forces[i].x += (dx / distance) * strength; forces[i].y += (dy / distance) * strength;
        forces[j].x -= (dx / distance) * strength; forces[j].y -= (dy / distance) * strength;
      }
    }
    links.forEach(({ source, target }) => {
      const dx = positions[target].x - positions[source].x; const dy = positions[target].y - positions[source].y;
      const distance = Math.max(1, Math.hypot(dx, dy)); const force = (distance - 205) * 0.006;
      forces[source].x += (dx / distance) * force; forces[source].y += (dy / distance) * force;
      forces[target].x -= (dx / distance) * force; forces[target].y -= (dy / distance) * force;
    });
    positions.forEach((position, index) => {
      const anchorPull = 0.035; const damping = 0.72;
      forces[index].x += (position.anchorX - position.x) * anchorPull;
      forces[index].y += (position.anchorY - position.y) * anchorPull;
      position.x = Math.max(72, Math.min(888, position.x + forces[index].x * damping));
      position.y = Math.max(68, Math.min(488, position.y + forces[index].y * damping));
    });
  }
  return positions.map(({ node, x, y }) => ({ ...node, x, y }));
}

export function graphLabelLines(label: string): string[] {
  if (label.length <= 18) return [label];
  const midpoint = Math.ceil(label.length / 2);
  const split = label.lastIndexOf(" ", midpoint);
  return split > 5 ? [label.slice(0, split), label.slice(split + 1)] : [label.slice(0, 18), `${label.slice(18, 30)}${label.length > 30 ? "…" : ""}`];
}
